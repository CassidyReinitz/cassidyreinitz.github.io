'use strict';
// Real Express routes, Passport strategy, JWT verification and password hashing.
// Persistence methods alone are stubbed: these tests do not prove live MongoDB behavior.
const { test, before, after, beforeEach } = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const express = require('express');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const passport = require('passport');
process.env.JWT_SECRET = crypto.randomBytes(32).toString('hex');
require('../app_api/models/user');
require('../app_api/models/travlr');
require('../app_api/config/passport');
const User = mongoose.model('User');
const Trip = mongoose.model('trips');
let server, base, calls, mode, account;
const validTrip = { code: ' beach-01 ', name: 'Beach Escape', length: '5 nights',
  start: '2026-10-01', resort: 'Paradise', perPerson: '1299.00',
  image: 'reef3.jpg', description: 'A relaxing trip.' };
const token = (payload = { _id: 'test-user', email: 'test@example.com' }, options = {}, secret = process.env.JWT_SECRET) =>
  jwt.sign(payload, secret, { algorithm: 'HS256', issuer: 'travlr-api',
    audience: 'travlr-admin', expiresIn: '2h', ...options });
async function request(method, path, body, authorization) {
  const headers = {};
  if (body !== undefined) headers['content-type'] = 'application/json';
  if (authorization !== undefined) headers.authorization = authorization;
  const result = await fetch(base + path, { method, headers,
    body: body === undefined ? undefined : JSON.stringify(body) });
  return { status: result.status, body: await result.json() };
}
function failure() { return Object.assign(new Error('private-db-password-and-stack'), mode === 'duplicate' ? { code: 11000 } : {}); }
before(async () => {
  account = new User({ name: 'Test', email: 'test@example.com' });
  account.setPassword('correct-password');
  User.findOne = async () => {
    calls.push('user-find');
    if (mode === 'db-error') throw failure();
    return mode === 'unknown-user' ? null : account;
  };
  User.prototype.save = async function () {
    calls.push('user-save'); if (mode !== 'ok') throw failure(); return this;
  };
  Trip.find = () => ({ exec: async () => {
    calls.push('find'); if (mode === 'db-error') throw failure();
    return mode === 'missing' ? [] : [{ code: 'BEACH-01' }];
  } });
  Trip.create = async value => {
    calls.push(['create', value]); if (mode !== 'ok') throw failure(); return value;
  };
  Trip.findOne = filter => ({ exec: async () => {
    calls.push(['findOne', filter]); if (mode === 'db-error') throw failure();
    if (mode === 'missing') return null;
    return { code: filter.code, save: async function () {
      calls.push('save'); if (mode === 'duplicate') throw failure(); return { code: this.code };
    } };
  } });
  Trip.findOneAndDelete = filter => ({ exec: async () => {
    calls.push(['delete', filter]); if (mode === 'db-error') throw failure();
    return mode === 'missing' ? null : { code: filter.code };
  } });
  const app = express();
  app.use(express.json());
  app.use(passport.initialize());
  app.use('/api', require('../app_api/routes'));
  server = app.listen(0, '127.0.0.1');
  await new Promise(resolve => server.once('listening', resolve));
  base = 'http://127.0.0.1:' + server.address().port;
});
beforeEach(() => { calls = []; mode = 'ok'; });
after(async () => { await new Promise(resolve => server.close(resolve)); });

for (const [label, auth] of [
  ['missing', undefined], ['wrong scheme', 'Basic abc'], ['malformed', 'Bearer broken'],
  ['expired', () => 'Bearer ' + token({}, { expiresIn: -1 })],
  ['wrong signature', () => 'Bearer ' + token({}, {}, 'other-secret')],
  ['wrong issuer', () => 'Bearer ' + token({}, { issuer: 'other' })],
  ['wrong audience', () => 'Bearer ' + token({}, { audience: 'other' })],
  ['wrong algorithm', () => 'Bearer ' + token({}, { algorithm: 'HS384' })],
  ['future not-before', () => 'Bearer ' + token({}, { notBefore: '1h' })]
]) {
  test('POST denies ' + label + ' token before persistence', async () => {
    const r = await request('POST', '/api/trips', validTrip, typeof auth === 'function' ? auth() : auth);
    assert.equal(r.status, 401); assert.equal(calls.length, 0);
  });
}
for (const method of ['PUT', 'DELETE']) {
  test(method + ' denies unauthenticated writes before persistence', async () => {
    const r = await request(method, '/api/trips/BEACH-01', validTrip);
    assert.equal(r.status, 401); assert.equal(calls.length, 0);
  });
}
test('authenticated POST normalizes input and discards privilege and operator fields', async () => {
  const r = await request('POST', '/api/trips', { ...validTrip, isAdmin: true, $set: { name: 'injected' } }, 'Bearer ' + token());
  assert.equal(r.status, 201); assert.equal(r.body.code, 'BEACH-01');
  assert.equal(Object.hasOwn(calls[0][1], 'isAdmin'), false);
  assert.equal(Object.hasOwn(calls[0][1], '$set'), false);
});
test('invalid authenticated POST is rejected before persistence', async () => {
  const r = await request('POST', '/api/trips', { ...validTrip, code: '../admin' }, 'Bearer ' + token());
  assert.equal(r.status, 400); assert.equal(calls.length, 0);
});
test('authenticated PUT updates one normalized trip', async () => {
  const r = await request('PUT', '/api/trips/beach-01', validTrip, 'Bearer ' + token());
  assert.equal(r.status, 200); assert.deepEqual(calls[0], ['findOne', { code: 'BEACH-01' }]);
  assert.ok(calls.includes('save'));
});
test('authenticated DELETE targets the requested normalized code', async () => {
  const r = await request('DELETE', '/api/trips/beach-01', undefined, 'Bearer ' + token());
  assert.equal(r.status, 200); assert.deepEqual(calls[0], ['delete', { code: 'BEACH-01' }]);
});
test('public trip reads remain available without a token', async () => {
  const r = await request('GET', '/api/trips');
  assert.equal(r.status, 200); assert.deepEqual(r.body, [{ code: 'BEACH-01' }]);
});
for (const [method, path, status, expected] of [
  ['GET', '/api/trips', 500, 'Error retrieving trips.'],
  ['GET', '/api/trips/BEACH-01', 500, 'Error retrieving trip.'],
  ['POST', '/api/trips', 400, 'Unable to add trip.'],
  ['PUT', '/api/trips/BEACH-01', 400, 'Unable to update trip.'],
  ['DELETE', '/api/trips/BEACH-01', 500, 'Error deleting trip.']
]) {
  test(method + ' ' + path + ' sanitizes database failure', async () => {
    mode = 'db-error';
    const r = await request(method, path, ['POST', 'PUT'].includes(method) ? validTrip : undefined, 'Bearer ' + token());
    assert.equal(r.status, status); assert.deepEqual(r.body, { message: expected });
    assert.equal(JSON.stringify(r.body).includes('private-db'), false);
  });
}
for (const method of ['POST', 'PUT']) {
  test(method + ' reports duplicate trip as conflict', async () => {
    mode = 'duplicate';
    const r = await request(method, '/api/trips' + (method === 'PUT' ? '/BEACH-01' : ''), validTrip, 'Bearer ' + token());
    assert.equal(r.status, 409);
  });
}
for (const method of ['GET', 'PUT', 'DELETE']) {
  test(method + ' reports missing trip', async () => {
    mode = 'missing';
    const r = await request(method, '/api/trips/UNKNOWN', method === 'PUT' ? validTrip : undefined, 'Bearer ' + token());
    assert.equal(r.status, 404);
  });
}
test('login authenticates through real Passport and returns a constrained JWT', async () => {
  const r = await request('POST', '/api/login', { email: ' TEST@EXAMPLE.COM ', password: 'correct-password' });
  assert.equal(r.status, 200);
  const payload = jwt.verify(r.body.token, process.env.JWT_SECRET, { algorithms: ['HS256'], issuer: 'travlr-api', audience: 'travlr-admin' });
  assert.equal(payload.email, 'test@example.com'); assert.equal(payload.exp - payload.iat, 7200);
  assert.equal(Object.hasOwn(payload, 'hash'), false);
});
test('wrong password and unknown account return the same generic response', async () => {
  const wrong = await request('POST', '/api/login', { email: 'test@example.com', password: 'wrong-password' });
  mode = 'unknown-user';
  const unknown = await request('POST', '/api/login', { email: 'missing@example.com', password: 'wrong-password' });
  assert.equal(wrong.status, 401); assert.deepEqual(wrong, unknown);
});
test('login database failure returns sanitized 500', async () => {
  mode = 'db-error';
  const r = await request('POST', '/api/login', { email: 'test@example.com', password: 'correct-password' });
  assert.equal(r.status, 500); assert.deepEqual(r.body, { message: 'Unable to complete login.' });
});
test('malformed login is rejected before account lookup', async () => {
  const r = await request('POST', '/api/login', { email: 'bad', password: '' });
  assert.equal(r.status, 400); assert.equal(calls.length, 0);
});
test('registration rejects weak credentials before persistence', async () => {
  const r = await request('POST', '/api/register', { name: '', email: 'bad', password: 'short' });
  assert.equal(r.status, 400); assert.equal(calls.length, 0);
});
test('registration duplicate and persistence failures are sanitized', async () => {
  const body = { name: 'Test', email: 'test@example.com', password: 'correct-password' };
  mode = 'duplicate'; assert.equal((await request('POST', '/api/register', body)).status, 409);
  mode = 'db-error'; const r = await request('POST', '/api/register', body);
  assert.equal(r.status, 400); assert.deepEqual(r.body, { message: 'Unable to create account.' });
});
test('password hashing creates distinct salts and accepts only correct passwords', () => {
  const other = new User({ email: 'other@example.com', name: 'Other' }); other.setPassword('correct-password');
  assert.notEqual(other.salt, account.salt); assert.notEqual(other.hash, account.hash);
  assert.equal(other.passwordIterations, 120000);
  assert.equal(other.validPassword('correct-password'), true); assert.equal(other.validPassword('wrong'), false);
});
test('legacy password records remain verifiable', () => {
  const legacy = new User({ name: 'Legacy', email: 'legacy@example.com', salt: 'legacy-test-salt' });
  legacy.hash = crypto.pbkdf2Sync('legacy-password', legacy.salt, 1000, 64, 'sha512').toString('hex');
  assert.equal(legacy.validPassword('legacy-password'), true); assert.equal(legacy.validPassword('wrong'), false);
});
test('malformed stored hash is rejected without a length exception', () => {
  const user = new User({ salt: 'test-salt', hash: '00', passwordIterations: 1000 });
  assert.equal(user.validPassword('password'), false);
});

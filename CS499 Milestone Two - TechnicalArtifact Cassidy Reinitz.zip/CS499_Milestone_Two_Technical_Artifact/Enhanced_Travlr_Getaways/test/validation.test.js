const test = require('node:test');
const assert = require('node:assert/strict');
const {
  normalizeTripInput,
  validateTripValues
} = require('../app_api/middleware/validation');

const validTrip = {
  code: ' beach-01 ',
  name: ' Beach Escape ',
  length: '5 nights',
  start: '2026-10-01',
  resort: 'Paradise Cove',
  perPerson: '1299.00',
  image: 'reef3.jpg',
  description: 'A relaxing beach vacation.'
};

test('normalizes trusted trip fields without accepting arbitrary properties', () => {
  const normalized = normalizeTripInput({ ...validTrip, isAdmin: true });
  assert.equal(normalized.code, 'BEACH-01');
  assert.equal(normalized.name, 'Beach Escape');
  assert.equal(Object.hasOwn(normalized, 'isAdmin'), false);
});

test('accepts a complete and valid trip', () => {
  assert.deepEqual(validateTripValues(normalizeTripInput(validTrip)), []);
});

test('rejects unsafe codes, prices, images, and missing descriptions', () => {
  const invalid = normalizeTripInput({
    ...validTrip,
    code: '../admin',
    perPerson: '-10',
    image: '../../secret.txt',
    description: ''
  });
  const errors = validateTripValues(invalid);
  assert.equal(errors.length, 4);
});

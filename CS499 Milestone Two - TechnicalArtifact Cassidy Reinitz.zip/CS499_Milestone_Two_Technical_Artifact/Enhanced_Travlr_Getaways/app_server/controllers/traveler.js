// URL for the API endpoint
const apiOptions = {
    server: 'http://localhost:3000'
};

// Render the Travel page
const travel = async (req, res) => {
    const path = '/api/trips';
    const requestOptions = {
        method: 'GET'
    };

    try {
        const response = await fetch(
            apiOptions.server + path,
            requestOptions
        );

        const json = await response.json();

        if (!Array.isArray(json)) {
            return res
                .status(500)
                .render('error', {
                    message: 'API lookup error',
                    error: {}
                });
        }

        if (json.length === 0) {
            return res.render('travel', {
                title: 'Travlr Getaways',
                trips: []
            });
        }

        return res.render('travel', {
            title: 'Travlr Getaways',
            trips: json
        });

    } catch (err) {
        return res
            .status(500)
            .send(err.message);
    }
};

module.exports = {
    travel
};
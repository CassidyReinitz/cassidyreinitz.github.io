const express = require('express');
const router = express.Router();

const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');
const { authenticateJWT } = require('../middleware/auth');
const {
    validateTrip,
    validateRegistration,
    validateLogin
} = require('../middleware/validation');

// User registration
router
    .route('/register')
    .post(validateRegistration, authController.register);

// User login
router
    .route('/login')
    .post(validateLogin, authController.login);

// List all trips / Add a new trip
router
    .route('/trips')
    .get(tripsController.tripsList)
    .post(authenticateJWT, validateTrip, tripsController.tripsAddTrip);

// Find, update, or delete one trip
router
    .route('/trips/:tripCode')
    .get(tripsController.tripsFindByCode)
    .put(authenticateJWT, validateTrip, tripsController.tripsUpdateTrip)
    .delete(authenticateJWT, tripsController.tripsDeleteTrip);

module.exports = router;

const jwt = require('jsonwebtoken');

const authenticateJWT = (req, res, next) => {
  const authorization = req.get('authorization') || '';
  const match = authorization.match(/^Bearer\s+([^\s]+)$/i);

  if (!match) {
    return res.status(401).json({
      message: 'A valid Bearer token is required.'
    });
  }

  try {
    req.auth = jwt.verify(match[1], process.env.JWT_SECRET, {
      algorithms: ['HS256'],
      issuer: 'travlr-api',
      audience: 'travlr-admin'
    });
    return next();
  } catch (err) {
    return res.status(401).json({
      message: 'The authentication token is invalid or expired.'
    });
  }
};

module.exports = { authenticateJWT };

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const CODE_PATTERN = /^[A-Z0-9-]{3,20}$/;
const PRICE_PATTERN = /^\d+(\.\d{1,2})?$/;
const IMAGE_PATTERN = /^[A-Za-z0-9_.-]+\.(jpg|jpeg|png|webp)$/i;

const clean = (value) => typeof value === 'string' ? value.trim() : '';

const validationFailure = (res, errors) => res.status(400).json({
  message: 'Validation failed.',
  errors
});

const normalizeTripInput = (body = {}) => ({
  code: clean(body.code).toUpperCase(),
  name: clean(body.name),
  length: clean(body.length),
  start: clean(body.start),
  resort: clean(body.resort),
  perPerson: clean(body.perPerson),
  image: clean(body.image),
  description: clean(body.description)
});

const validateTripValues = (trip) => {
  const errors = [];

  if (!CODE_PATTERN.test(trip.code)) {
    errors.push('Trip code must be 3-20 uppercase letters, numbers, or hyphens.');
  }
  if (!trip.name || trip.name.length > 100) {
    errors.push('Trip name is required and must be 100 characters or fewer.');
  }
  if (!trip.length || trip.length.length > 50) {
    errors.push('Trip length is required and must be 50 characters or fewer.');
  }
  if (!trip.start || Number.isNaN(Date.parse(trip.start))) {
    errors.push('A valid trip start date is required.');
  }
  if (!trip.resort || trip.resort.length > 100) {
    errors.push('Resort is required and must be 100 characters or fewer.');
  }
  if (!PRICE_PATTERN.test(trip.perPerson) || Number(trip.perPerson) <= 0) {
    errors.push('Price per person must be a positive amount with up to two decimal places.');
  }
  if (!IMAGE_PATTERN.test(trip.image)) {
    errors.push('Image must be a safe JPG, JPEG, PNG, or WEBP filename.');
  }
  if (!trip.description || trip.description.length > 2000) {
    errors.push('Description is required and must be 2,000 characters or fewer.');
  }

  return errors;
};

const validateTrip = (req, res, next) => {
  const trip = normalizeTripInput(req.body);
  const errors = validateTripValues(trip);

  if (errors.length) {
    return validationFailure(res, errors);
  }

  req.validatedTrip = trip;
  return next();
};

const normalizeEmail = (value) => clean(value).toLowerCase();

const validateRegistration = (req, res, next) => {
  const name = clean(req.body.name);
  const email = normalizeEmail(req.body.email);
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  const errors = [];

  if (!name || name.length > 100) errors.push('Name is required and must be 100 characters or fewer.');
  if (!EMAIL_PATTERN.test(email) || email.length > 254) errors.push('A valid email address is required.');
  if (password.length < 10 || password.length > 128) errors.push('Password must be 10-128 characters.');

  if (errors.length) return validationFailure(res, errors);
  req.validatedUser = { name, email, password };
  return next();
};

const validateLogin = (req, res, next) => {
  const email = normalizeEmail(req.body.email);
  const password = typeof req.body.password === 'string' ? req.body.password : '';

  if (!EMAIL_PATTERN.test(email) || !password) {
    return validationFailure(res, ['A valid email address and password are required.']);
  }

  req.validatedUser = { email, password };
  req.body.email = email;
  return next();
};

module.exports = {
  normalizeTripInput,
  validateTripValues,
  validateTrip,
  validateRegistration,
  validateLogin
};

const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;
const mongoose = require('mongoose');

const User = mongoose.model('User');

passport.use(
  new LocalStrategy(
    {
      usernameField: 'email'
    },
    (username, password, done) => {
      User.findOne({ email: String(username || '').trim().toLowerCase() })
        .then((user) => {
          if (!user) {
            return done(null, false, {
              message: 'Invalid email or password.'
            });
          }

          if (!user.validPassword(password)) {
            return done(null, false, {
              message: 'Invalid email or password.'
            });
          }

          return done(null, user);
        })
        .catch((err) => done(err));
    }
  )
);

const passport = require('passport');
const mongoose = require('mongoose');

const User = mongoose.model('User');

const register = async (req, res) => {
    try {
        const user = new User();
        const { name, email, password } = req.validatedUser;

        user.name = name;
        user.email = email;
        user.setPassword(password);

        await user.save();

        const token = user.generateJWT();

        return res.status(201).json({ token });
    } catch (err) {
        if (err && err.code === 11000) {
            return res.status(409).json({ message: 'An account with that email already exists.' });
        }
        return res.status(400).json({ message: 'Unable to create account.' });
    }
};

const login = (req, res) => {
    passport.authenticate('local', (err, user, info) => {
        if (err) {
            return res.status(500).json({ message: 'Unable to complete login.' });
        }

        if (user) {
            const token = user.generateJWT();
            return res.status(200).json({ token });
        }

        return res.status(401).json({ message: 'Invalid email or password.' });
    })(req, res);
};

module.exports = {
    register,
    login
};

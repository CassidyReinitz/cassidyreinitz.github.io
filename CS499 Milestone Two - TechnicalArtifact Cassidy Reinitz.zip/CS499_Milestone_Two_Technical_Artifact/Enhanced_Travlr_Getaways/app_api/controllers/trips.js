const mongoose = require('mongoose');
const Trip = mongoose.model('trips');

const safeServerError = (res, message) => res.status(500).json({ message });
const normalizedCode = (value) => String(value || '').trim().toUpperCase();

const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find({}).exec();

    if (!trips || trips.length === 0) {
      return res
        .status(404)
        .json({ message: 'No trips found' });
    }

    return res
      .status(200)
      .json(trips);
  } catch (err) {
    return safeServerError(res, 'Error retrieving trips.');
  }
};

const tripsFindByCode = async (req, res) => {
  try {
    const trip = await Trip
      .findOne({ code: normalizedCode(req.params.tripCode) })
      .exec();

    if (!trip) {
      return res
        .status(404)
        .json({ message: 'Trip not found' });
    }

    return res
      .status(200)
      .json(trip);
  } catch (err) {
    return safeServerError(res, 'Error retrieving trip.');
  }
};

const tripsAddTrip = async (req, res) => {
  try {
    const newTrip = await Trip.create(req.validatedTrip);

    return res
      .status(201)
      .json(newTrip);
  } catch (err) {
    if (err && err.code === 11000) {
      return res.status(409).json({ message: 'A trip with that code already exists.' });
    }
    return res.status(400).json({ message: 'Unable to add trip.' });
  }
};

const tripsUpdateTrip = async (req, res) => {
  try {
    const trip = await Trip
      .findOne({ code: normalizedCode(req.params.tripCode) })
      .exec();

    if (!trip) {
      return res
        .status(404)
        .json({ message: 'Trip not found' });
    }

    Object.assign(trip, req.validatedTrip);

    const updatedTrip = await trip.save();

    return res
      .status(200)
      .json(updatedTrip);
  } catch (err) {
    if (err && err.code === 11000) {
      return res.status(409).json({ message: 'A trip with that code already exists.' });
    }
    return res.status(400).json({ message: 'Unable to update trip.' });
  }
};

const tripsDeleteTrip = async (req, res) => {
  try {
    const deletedTrip = await Trip
      .findOneAndDelete({ code: normalizedCode(req.params.tripCode) })
      .exec();

    if (!deletedTrip) {
      return res
        .status(404)
        .json({ message: 'Trip not found' });
    }

    return res
      .status(200)
      .json({
        message: 'Trip deleted successfully',
        trip: deletedTrip
      });
  } catch (err) {
    return safeServerError(res, 'Error deleting trip.');
  }
};

module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip
};

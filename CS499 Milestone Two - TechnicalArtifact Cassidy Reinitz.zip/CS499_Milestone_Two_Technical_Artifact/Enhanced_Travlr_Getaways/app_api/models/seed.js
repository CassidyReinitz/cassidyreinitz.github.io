const fs = require('fs');
const mongoose = require('mongoose');
const path = require('path');

const host = process.env.DB_HOST || '127.0.0.1';
const dbURI = `mongodb://${host}/travlr`;

const Trip = require('./travlr');

const tripsPath = path.join(__dirname, '../../data/trips.json');
const trips = JSON.parse(fs.readFileSync(tripsPath, 'utf8'));

const seedDB = async () => {
    try {
        await mongoose.connect(dbURI);
        console.log(`Connected to ${dbURI}`);

        await Trip.deleteMany({});
        console.log('Existing trips removed');

        await Trip.insertMany(trips);
        console.log(`${trips.length} trips inserted`);

        await mongoose.connection.close();
        console.log('Database connection closed');
    } catch (err) {
        console.error('Database seed error:', err);
        await mongoose.connection.close();
        process.exit(1);
    }
};

seedDB();
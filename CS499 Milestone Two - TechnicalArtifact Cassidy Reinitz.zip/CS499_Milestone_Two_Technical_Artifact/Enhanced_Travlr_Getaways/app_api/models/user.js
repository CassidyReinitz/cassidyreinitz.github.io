const mongoose = require('mongoose');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const PASSWORD_ITERATIONS = 120000;

const userSchema = new mongoose.Schema({
  email: {
    type: String,
    unique: true,
    required: true,
    trim: true,
    lowercase: true,
    maxlength: 254
  },
  name: {
    type: String,
    required: true
  },
  hash: String,
  salt: String,
  passwordIterations: Number
});

// Method to set the password on this record.
userSchema.methods.setPassword = function(password) {
  this.salt = crypto.randomBytes(16).toString('hex');
  this.passwordIterations = PASSWORD_ITERATIONS;
  this.hash = crypto.pbkdf2Sync(
    password,
    this.salt,
    this.passwordIterations,
    64,
    'sha512'
  ).toString('hex');
};

// Method to validate a submitted password.
userSchema.methods.validPassword = function(password) {
  const iterations = this.passwordIterations || 1000;
  const submittedHash = crypto.pbkdf2Sync(
    password,
    this.salt,
    iterations,
    64,
    'sha512'
  ).toString('hex');

  const stored = Buffer.from(this.hash, 'hex');
  const submitted = Buffer.from(submittedHash, 'hex');
  return stored.length === submitted.length && crypto.timingSafeEqual(stored, submitted);
};

// Method to generate a JSON Web Token.
userSchema.methods.generateJWT = function() {
  return jwt.sign(
    {
      _id: this._id,
      email: this.email,
      name: this.name
    },
    process.env.JWT_SECRET,
    {
      algorithm: 'HS256',
      expiresIn: process.env.JWT_EXPIRES_IN || '2h',
      issuer: 'travlr-api',
      audience: 'travlr-admin'
    }
  );
};

mongoose.model('User', userSchema);

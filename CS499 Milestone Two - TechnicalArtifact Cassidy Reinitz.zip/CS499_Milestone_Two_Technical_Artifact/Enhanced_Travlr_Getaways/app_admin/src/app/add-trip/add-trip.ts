import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TripData } from '../trip-data';
import { HttpErrorResponse } from '@angular/common/http';
import { Trip } from '../models/trip';

@Component({
  selector: 'app-add-trip',
  imports: [CommonModule, FormsModule],
  templateUrl: './add-trip.html',
  styleUrl: './add-trip.css',
})
export class AddTrip {
  message = signal('');

  newTrip: Trip = {
    code: '',
    name: '',
    length: '',
    start: '',
    resort: '',
    perPerson: '',
    image: '',
    description: ''
  };

  constructor(private tripData: TripData) {}

  addTrip(): void {
    const trip: Trip = {
      ...this.newTrip,
      code: this.newTrip.code.trim().toUpperCase(),
      name: this.newTrip.name.trim(),
      length: this.newTrip.length.trim(),
      resort: this.newTrip.resort.trim(),
      perPerson: String(this.newTrip.perPerson).trim(),
      image: this.newTrip.image.trim(),
      description: this.newTrip.description.trim()
    };

    this.tripData.addTrip(trip).subscribe({
      next: () => {
        this.message.set('Trip added successfully!');

        this.newTrip = {
          code: '',
          name: '',
          length: '',
          start: '',
          resort: '',
          perPerson: '',
          image: '',
          description: ''
        };
      },
      error: (err: HttpErrorResponse) => {
        console.error('Error adding trip:', err);
        this.message.set(err.error?.message || 'Error adding trip.');
      }
    });
  }
}

import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { Authentication } from '../services/authentication';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule
  ],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login {
  credentials = {
    email: '',
    password: ''
  };

  errorMessage = '';

  constructor(
    private authenticationService: Authentication,
    private router: Router
  ) {}

  onLoginSubmit(): void {
    this.errorMessage = '';

    if (!this.credentials.email || !this.credentials.password) {
      this.errorMessage = 'Email and password are required.';
      return;
    }

    this.authenticationService.login({
      email: this.credentials.email.trim().toLowerCase(),
      password: this.credentials.password
    }).subscribe({
      next: () => this.router.navigate(['/']),
      error: () => {
        this.errorMessage = 'Login failed. Please check your email and password.';
      }
    });
  }
}

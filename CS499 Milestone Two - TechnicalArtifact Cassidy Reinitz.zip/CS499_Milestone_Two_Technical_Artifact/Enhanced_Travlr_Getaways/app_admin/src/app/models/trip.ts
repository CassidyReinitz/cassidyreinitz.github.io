export interface Trip {
  code: string;
  name: string;
  length: string;
  start: string;
  resort: string;
  perPerson: string;
  image: string;
  description: string;
}

export interface ApiMessage {
  message: string;
}

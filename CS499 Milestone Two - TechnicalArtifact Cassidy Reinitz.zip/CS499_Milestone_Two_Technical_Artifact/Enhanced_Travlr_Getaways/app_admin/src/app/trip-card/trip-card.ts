import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';

import { Authentication } from '../services/authentication';

@Component({
  selector: 'app-trip-card',
  imports: [CommonModule],
  templateUrl: './trip-card.html',
  styleUrl: './trip-card.css',
})
export class TripCard implements OnInit {
  @Input() trip: any;

  constructor(
    public authenticationService: Authentication
  ) {}

  ngOnInit(): void {}
}
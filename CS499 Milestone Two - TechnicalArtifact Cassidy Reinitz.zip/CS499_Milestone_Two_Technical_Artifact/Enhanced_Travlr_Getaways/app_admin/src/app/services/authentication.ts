import { Inject, Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, tap } from 'rxjs';

import { User } from '../models/user';
import { AuthResponse } from '../models/auth-response';
import { BROWSER_STORAGE } from '../storage';

@Injectable({
  providedIn: 'root'
})
export class Authentication {
  private apiBaseUrl = 'http://localhost:3000/api';

  constructor(
    private http: HttpClient,
    @Inject(BROWSER_STORAGE) private storage: Storage
  ) {}

  public getToken(): string {
    return this.storage.getItem('travlr-token') || '';
  }

  public saveToken(token: string): void {
    this.storage.setItem('travlr-token', token);
  }

  public logout(): void {
    this.storage.removeItem('travlr-token');
  }

  private decodeToken(token: string): any {
    try {
      const payload = token.split('.')[1];

      const base64 = payload
        .replace(/-/g, '+')
        .replace(/_/g, '/');

      const padded = base64.padEnd(
        base64.length + (4 - base64.length % 4) % 4,
        '='
      );

      return JSON.parse(atob(padded));
    } catch (err) {
      console.error('Unable to decode JWT:', err);
      return null;
    }
  }

  public isLoggedIn(): boolean {
    const token = this.getToken();

    if (!token) {
      return false;
    }

    const payload = this.decodeToken(token);

    if (!payload || !payload.exp) {
      return false;
    }

    return payload.exp > Date.now() / 1000;
  }

  public getCurrentUser(): User | null {
    const token = this.getToken();

    if (!token || !this.isLoggedIn()) {
      return null;
    }

    const payload = this.decodeToken(token);

    if (!payload) {
      return null;
    }

    const user = new User();

    user.email = payload.email || '';
    user.name = payload.name || '';

    return user;
  }

  private makeAuthApiCall(
    urlPath: string,
    user: {
      name?: string;
      email: string;
      password: string;
    }
  ): Observable<AuthResponse> {
    const url = `${this.apiBaseUrl}/${urlPath}`;

    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    };

    return this.http.post<AuthResponse>(
      url,
      user,
      httpOptions
    );
  }

  public login(user: {
    email: string;
    password: string;
  }): Observable<AuthResponse> {
    return this.makeAuthApiCall('login', user)
      .pipe(
        tap((authResp: AuthResponse) => {
          this.saveToken(authResp.token);
        })
      );
  }

  public register(user: {
    name: string;
    email: string;
    password: string;
  }): Observable<AuthResponse> {
    return this.makeAuthApiCall('register', user)
      .pipe(
        tap((authResp: AuthResponse) => {
          this.saveToken(authResp.token);
        })
      );
  }
}
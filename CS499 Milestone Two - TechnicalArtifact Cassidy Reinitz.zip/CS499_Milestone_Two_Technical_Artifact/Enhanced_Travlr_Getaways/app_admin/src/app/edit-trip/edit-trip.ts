import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TripData } from '../trip-data';
import { HttpErrorResponse } from '@angular/common/http';
import { Trip } from '../models/trip';

@Component({
  selector: 'app-edit-trip',
  imports: [CommonModule, FormsModule],
  templateUrl: './edit-trip.html',
  styleUrl: './edit-trip.css',
})
export class EditTrip {
  message = signal('');

  tripCode = '';

  trip: Trip = {
    code: '',
    name: '',
    length: '',
    start: '',
    resort: '',
    perPerson: '',
    image: '',
    description: ''
  };

  constructor(private tripData: TripData) {}

  loadTrip(): void {
    const requestedCode = this.tripCode.trim().toUpperCase();
    if (!requestedCode) {
      this.message.set('Enter a trip code first.');
      return;
    }

    this.tripData.getTrip(requestedCode).subscribe({
      next: (data) => {
        this.trip = {
          code: data.code ?? '',
          name: data.name ?? '',
          length: data.length ?? '',
          start: data.start ? data.start.substring(0, 10) : '',
          resort: data.resort ?? '',
          perPerson: data.perPerson ?? '',
          image: data.image ?? '',
          description: data.description ?? ''
        };

        this.message.set('Trip loaded successfully.');
      },
      error: (err: HttpErrorResponse) => {
        console.error('Error loading trip:', err);
        this.message.set('Trip not found.');
      }
    });
  }

  updateTrip(): void {
    const originalCode = this.tripCode.trim().toUpperCase();
    const updatedTrip: Trip = {
      ...this.trip,
      code: this.trip.code.trim().toUpperCase(),
      name: this.trip.name.trim(),
      length: this.trip.length.trim(),
      resort: this.trip.resort.trim(),
      perPerson: String(this.trip.perPerson).trim(),
      image: this.trip.image.trim(),
      description: this.trip.description.trim()
    };

    this.tripData.updateTrip(originalCode, updatedTrip).subscribe({
      next: () => {
        this.message.set('Trip updated successfully!');
        this.trip = updatedTrip;
        this.tripCode = updatedTrip.code;
      },
      error: (err: HttpErrorResponse) => {
        console.error('Error updating trip:', err);
        this.message.set(err.error?.message || 'Error updating trip.');
      }
    });
  }
}

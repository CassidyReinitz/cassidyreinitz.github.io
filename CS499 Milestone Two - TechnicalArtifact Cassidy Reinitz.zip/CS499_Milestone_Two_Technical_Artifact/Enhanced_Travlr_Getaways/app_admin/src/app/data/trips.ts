export const trips = [
  {
    code: 'GALR210214',
    name: 'Gale Reef',
    length: '4 nights / 5 days',
    start: '2021-02-14T00:00:00.000Z',
    resort: 'Emerald Bay, 3 stars',
    perPerson: '799.00',
    image: 'reef1.jpg',
    description: 'A beautiful reef vacation package.'
  },
  {
    code: 'DAWR210315',
    name: 'Dawson Resort',
    length: '4 nights / 5 days',
    start: '2021-03-15T00:00:00.000Z',
    resort: 'Blue Lagoon, 4 stars',
    perPerson: '1199.00',
    image: 'reef2.jpg',
    description: 'Relax at a scenic tropical resort.'
  },
  {
    code: 'ROCR210429',
    name: 'Rocky Coast',
    length: '5 nights / 6 days',
    start: '2021-04-29T00:00:00.000Z',
    resort: 'Sunset Cove, 5 stars',
    perPerson: '1499.00',
    image: 'reef3.jpg',
    description: 'Enjoy a premium coastal getaway.'
  }
];
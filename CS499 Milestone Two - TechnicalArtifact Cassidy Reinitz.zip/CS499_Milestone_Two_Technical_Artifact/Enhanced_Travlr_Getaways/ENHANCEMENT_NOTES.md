# Software Design and Engineering Enhancement

This version refactors the Travlr Getaways application to make validation,
authentication, error handling, and data access behavior easier to maintain and
safer to operate.

## Major improvements

- Moved JWT verification into reusable authentication middleware.
- Added centralized request validation and normalization for trip and user data.
- Added schema constraints and unique trip codes to protect data integrity.
- Prevented arbitrary fields from being copied into database documents.
- Replaced detailed internal error responses with stable client-facing messages.
- Strengthened password hashing and constant-time password comparison.
- Shortened and constrained JWTs with issuer, audience, expiration, and algorithm checks.
- Made database, token, and administrative-origin settings environment configurable.
- Added route protection in the Angular application.
- Fixed the login workflow so it subscribes to the HTTP request rather than relying on a timer.
- Added typed trip models, clearer client error handling, and validation-focused tests.

## Verification

- Run `npm test` in the project root for backend validation tests.
- Run `npm run build` in `app_admin` to verify the Angular application compiles.
- Configure `.env` from `.env.example` before starting the Express server.

# CS 499 Milestone Two Technical Artifact

This submission contains the original and enhanced versions of the CS 465
Travlr Getaways full-stack application.

## Folder contents

- `Original_Travlr_Getaways`: unchanged Module 7 project used as the baseline.
- `Enhanced_Travlr_Getaways`: software design and engineering enhancement.

The enhanced version includes centralized validation, reusable authentication
middleware, safer API errors, stronger credential handling, database schema
constraints, protected Angular routes, typed client models, corrected login
flow, improved form validation, automated backend tests, and configuration
documentation. See `Enhanced_Travlr_Getaways/ENHANCEMENT_NOTES.md` for details.

## Verification completed

- Backend: `npm test` - 3 tests passed.
- Backend JavaScript: syntax checks passed.
- Angular admin: `npm run build` completed successfully.

Generated dependency and build folders are intentionally excluded. Run
`npm ci` in the enhanced project root and again in `app_admin` to restore them.

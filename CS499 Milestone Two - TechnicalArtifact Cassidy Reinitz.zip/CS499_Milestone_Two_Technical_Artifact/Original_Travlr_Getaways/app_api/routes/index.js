const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');

const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');

// Method to authenticate JWT
function authenticateJWT(req, res, next) {
    const authHeader = req.headers['authorization'];

    // Authorization header must be present
    if (!authHeader) {
        console.log('Auth Header Required but NOT PRESENT!');
        return res.sendStatus(401);
    }

    // Expected format: Bearer <token>
    const headers = authHeader.split(' ');

    if (headers.length < 2 || headers[0] !== 'Bearer') {
        console.log('Invalid Authorization Header');
        return res.sendStatus(401);
    }

    const token = headers[1];

    if (!token) {
        console.log('Null Bearer Token');
        return res.sendStatus(401);
    }

    // Verify the JWT using the secret stored in .env
    jwt.verify(token, process.env.JWT_SECRET, (err, verified) => {
        if (err) {
            console.log('Token Validation Error!');
            return res.status(401).json({
                message: 'Token Validation Error!'
            });
        }

        // Store decoded JWT data on the request
        req.auth = verified;

        // Continue to the protected controller
        next();
    });
}

// User registration
router
    .route('/register')
    .post(authController.register);

// User login
router
    .route('/login')
    .post(authController.login);

// List all trips / Add a new trip
router
    .route('/trips')
    .get(tripsController.tripsList)
    .post(authenticateJWT, tripsController.tripsAddTrip);

// Find, update, or delete one trip
router
    .route('/trips/:tripCode')
    .get(tripsController.tripsFindByCode)
    .put(authenticateJWT, tripsController.tripsUpdateTrip)
    .delete(authenticateJWT, tripsController.tripsDeleteTrip);

module.exports = router;
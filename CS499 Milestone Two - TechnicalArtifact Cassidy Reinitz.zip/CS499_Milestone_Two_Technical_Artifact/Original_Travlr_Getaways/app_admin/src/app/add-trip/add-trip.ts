import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TripData } from '../trip-data';

@Component({
  selector: 'app-add-trip',
  imports: [CommonModule, FormsModule],
  templateUrl: './add-trip.html',
  styleUrl: './add-trip.css',
})
export class AddTrip {
  message = signal('');

  newTrip = {
    code: '',
    name: '',
    length: '',
    start: '',
    resort: '',
    perPerson: '',
    image: '',
    description: ''
  };

  constructor(private tripData: TripData) {}

  addTrip(): void {
    this.tripData.addTrip(this.newTrip).subscribe({
      next: () => {
        this.message.set('Trip added successfully!');

        this.newTrip = {
          code: '',
          name: '',
          length: '',
          start: '',
          resort: '',
          perPerson: '',
          image: '',
          description: ''
        };
      },
      error: (err) => {
        console.error('Error adding trip:', err);
        this.message.set('Error adding trip.');
      }
    });
  }
}
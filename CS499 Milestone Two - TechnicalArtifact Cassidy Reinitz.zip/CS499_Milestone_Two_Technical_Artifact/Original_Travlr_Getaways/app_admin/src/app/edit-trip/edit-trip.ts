import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TripData } from '../trip-data';

@Component({
  selector: 'app-edit-trip',
  imports: [CommonModule, FormsModule],
  templateUrl: './edit-trip.html',
  styleUrl: './edit-trip.css',
})
export class EditTrip {
  message = signal('');

  tripCode = '';

  trip = {
    code: '',
    name: '',
    length: '',
    start: '',
    resort: '',
    perPerson: '',
    image: '',
    description: ''
  };

  constructor(private tripData: TripData) {}

  loadTrip(): void {
    if (!this.tripCode) {
      this.message.set('Enter a trip code first.');
      return;
    }

    this.tripData.getTrip(this.tripCode).subscribe({
      next: (data) => {
        this.trip = {
          code: data.code ?? '',
          name: data.name ?? '',
          length: data.length ?? '',
          start: data.start ? data.start.substring(0, 10) : '',
          resort: data.resort ?? '',
          perPerson: data.perPerson ?? '',
          image: data.image ?? '',
          description: data.description ?? ''
        };

        this.message.set('Trip loaded successfully.');
      },
      error: (err) => {
        console.error('Error loading trip:', err);
        this.message.set('Trip not found.');
      }
    });
  }

  updateTrip(): void {
    const originalCode = this.tripCode;

    this.tripData.updateTrip(originalCode, this.trip).subscribe({
      next: () => {
        this.message.set('Trip updated successfully!');
        this.tripCode = this.trip.code;
      },
      error: (err) => {
        console.error('Error updating trip:', err);
        this.message.set('Error updating trip.');
      }
    });
  }
}
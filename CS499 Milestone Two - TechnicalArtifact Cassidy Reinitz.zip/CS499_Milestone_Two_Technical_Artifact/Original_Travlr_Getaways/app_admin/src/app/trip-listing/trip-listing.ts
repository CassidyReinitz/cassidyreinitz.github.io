import { Component, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

import { TripCard } from '../trip-card/trip-card';
import { TripData } from '../trip-data';
import { Authentication } from '../services/authentication';

@Component({
  selector: 'app-trip-listing',
  imports: [
    CommonModule,
    RouterLink,
    TripCard
  ],
  templateUrl: './trip-listing.html',
  styleUrl: './trip-listing.css',
})
export class TripListing implements OnInit {
  trips = signal<any[]>([]);

  constructor(
    private tripData: TripData,
    public authenticationService: Authentication
  ) {}

  ngOnInit(): void {
    this.tripData.getTrips().subscribe({
      next: (data) => {
        this.trips.set(data);
      },
      error: (err) => {
        console.error('Error retrieving trips:', err);
      }
    });
  }
}
#include "CourseCatalog.h"
#include "InputValidation.h"

#include <iostream>
#include <string>

namespace {

void displayMenu() {
    std::cout << "\n1. Load course data\n"
              << "2. Print course list\n"
              << "3. Print course details\n"
              << "4. Print valid course sequence\n"
              << "9. Exit\n\n"
              << "What would you like to do? ";
}

void printErrors(const advising::LoadReport& report) {
    std::cout << "The catalog was not loaded because validation failed:\n";
    for (const std::string& error : report.errors) {
        std::cout << "  - " << error << '\n';
    }
}

void printCourseList(const advising::CourseCatalog& catalog) {
    if (catalog.empty()) {
        std::cout << "Course data has not been loaded. Choose option 1 first.\n";
        return;
    }
    for (const advising::Course& course : catalog.sortedCourses()) {
        std::cout << course.number << ", " << course.title << '\n';
    }
}

void printCourse(const advising::CourseCatalog& catalog,
                 const std::string& courseNumber) {
    const advising::Course* course = catalog.findCourse(courseNumber);
    if (course == nullptr) {
        std::cout << "Course " << courseNumber << " was not found.\n";
        return;
    }

    std::cout << course->number << ", " << course->title << '\n';
    std::cout << "Prerequisites: ";
    if (course->prerequisites.empty()) {
        std::cout << "None\n";
        return;
    }
    for (std::size_t i = 0; i < course->prerequisites.size(); ++i) {
        if (i > 0) {
            std::cout << ", ";
        }
        std::cout << course->prerequisites[i];
    }
    std::cout << '\n';
}

void printCourseSequence(const advising::CourseCatalog& catalog) {
    std::string error;
    const std::vector<std::string> order = catalog.topologicalOrder(&error);
    if (!error.empty()) {
        std::cout << error << '\n';
        return;
    }

    std::cout << "Valid prerequisite-respecting course sequence:\n";
    for (std::size_t i = 0; i < order.size(); ++i) {
        const advising::Course* course = catalog.findCourse(order[i]);
        std::cout << (i + 1) << ". " << order[i];
        if (course != nullptr) {
            std::cout << " - " << course->title;
        }
        std::cout << '\n';
    }
}

}  // namespace

int main() {
    advising::CourseCatalog catalog;
    std::cout << "Welcome to the enhanced course planner.\n";

    std::string input;
    while (true) {
        displayMenu();
        if (!std::getline(std::cin, input)) {
            std::cout << "\nInput closed. Exiting safely.\n";
            return 0;
        }

        const std::optional<int> choice = advising::parseMenuChoice(input);
        if (!choice.has_value()) {
            std::cout << "Enter one whole-number menu option.\n";
            continue;
        }

        switch (*choice) {
            case 1: {
                std::cout << "Enter the course-data filename: ";
                std::string filename;
                if (!std::getline(std::cin, filename)) {
                    std::cout << "Input closed. Exiting safely.\n";
                    return 0;
                }
                filename = advising::trimInput(filename);
                const advising::LoadReport report = catalog.loadFromFile(filename);
                if (report.success) {
                    std::cout << "Loaded and validated " << report.coursesLoaded
                              << " courses.\n";
                } else {
                    printErrors(report);
                }
                break;
            }
            case 2:
                printCourseList(catalog);
                break;
            case 3: {
                std::cout << "Enter a course number: ";
                std::string courseNumber;
                if (!std::getline(std::cin, courseNumber)) {
                    std::cout << "Input closed. Exiting safely.\n";
                    return 0;
                }
                printCourse(catalog, courseNumber);
                break;
            }
            case 4:
                printCourseSequence(catalog);
                break;
            case 9:
                std::cout << "Thank you for using the course planner!\n";
                return 0;
            default:
                std::cout << *choice << " is not a valid option.\n";
                break;
        }
    }
}

#include "CourseCatalog.h"

#include <algorithm>
#include <cctype>
#include <fstream>
#include <functional>
#include <queue>
#include <regex>
#include <sstream>
#include <unordered_set>
#include <utility>

namespace advising {
namespace {

std::string trim(const std::string& value) {
    std::size_t begin = 0;
    while (begin < value.size() &&
           std::isspace(static_cast<unsigned char>(value[begin])) != 0) {
        ++begin;
    }

    std::size_t end = value.size();
    while (end > begin &&
           std::isspace(static_cast<unsigned char>(value[end - 1])) != 0) {
        --end;
    }
    return value.substr(begin, end - begin);
}

bool parseCsvLine(const std::string& line,
                  std::vector<std::string>& fields,
                  std::string& error) {
    fields.clear();
    std::string field;
    bool quoted = false;

    for (std::size_t i = 0; i < line.size(); ++i) {
        const char current = line[i];
        if (current == '"') {
            if (quoted && i + 1 < line.size() && line[i + 1] == '"') {
                field.push_back('"');
                ++i;
            } else {
                quoted = !quoted;
            }
        } else if (current == ',' && !quoted) {
            fields.push_back(trim(field));
            field.clear();
        } else {
            field.push_back(current);
        }
    }

    if (quoted) {
        error = "contains an unterminated quoted field";
        return false;
    }

    fields.push_back(trim(field));
    return true;
}

bool isValidCourseNumber(const std::string& value) {
    static const std::regex pattern("^[A-Z]{2,5}[0-9]{3,4}$");
    return std::regex_match(value, pattern);
}

std::string joinCycle(const std::vector<std::string>& cycle) {
    std::ostringstream output;
    for (std::size_t i = 0; i < cycle.size(); ++i) {
        if (i > 0) {
            output << " -> ";
        }
        output << cycle[i];
    }
    return output.str();
}

}  // namespace

void CourseCatalog::clear() noexcept {
    courses_.clear();
    dependents_.clear();
    inDegree_.clear();
}

std::string CourseCatalog::normalizeCourseNumber(const std::string& value) {
    std::string normalized;
    normalized.reserve(value.size());
    for (const char character : trim(value)) {
        const unsigned char safe = static_cast<unsigned char>(character);
        if (std::isspace(safe) == 0) {
            normalized.push_back(static_cast<char>(std::toupper(safe)));
        }
    }
    return normalized;
}

LoadReport CourseCatalog::loadFromFile(const std::string& filename) {
    std::ifstream input(filename);
    if (!input.is_open()) {
        clear();
        LoadReport report;
        report.errors.push_back("Unable to open file: " + filename);
        return report;
    }
    return loadFromStream(input, filename);
}

LoadReport CourseCatalog::loadFromStream(std::istream& input,
                                         const std::string& sourceName) {
    clear();
    LoadReport report;
    std::unordered_map<std::string, Course> candidate;

    std::string line;
    std::size_t lineNumber = 0;
    while (std::getline(input, line)) {
        ++lineNumber;
        if (trim(line).empty()) {
            continue;
        }

        std::vector<std::string> fields;
        std::string csvError;
        if (!parseCsvLine(line, fields, csvError)) {
            report.errors.push_back(sourceName + ": line " +
                                    std::to_string(lineNumber) + " " + csvError);
            continue;
        }
        if (fields.size() < 2) {
            report.errors.push_back(sourceName + ": line " +
                                    std::to_string(lineNumber) +
                                    " must include a course number and title");
            continue;
        }

        Course course;
        course.number = normalizeCourseNumber(fields[0]);
        course.title = trim(fields[1]);

        if (!isValidCourseNumber(course.number)) {
            report.errors.push_back(sourceName + ": line " +
                                    std::to_string(lineNumber) +
                                    " has an invalid course number: " + fields[0]);
            continue;
        }
        if (course.title.empty()) {
            report.errors.push_back(sourceName + ": line " +
                                    std::to_string(lineNumber) +
                                    " has an empty course title");
            continue;
        }
        if (candidate.find(course.number) != candidate.end()) {
            report.errors.push_back(sourceName + ": line " +
                                    std::to_string(lineNumber) +
                                    " duplicates course " + course.number);
            continue;
        }

        std::unordered_set<std::string> uniquePrerequisites;
        bool courseHasError = false;
        for (std::size_t i = 2; i < fields.size(); ++i) {
            if (trim(fields[i]).empty()) {
                continue;
            }
            const std::string prerequisite = normalizeCourseNumber(fields[i]);
            if (!isValidCourseNumber(prerequisite)) {
                report.errors.push_back(sourceName + ": line " +
                                        std::to_string(lineNumber) +
                                        " has an invalid prerequisite: " + fields[i]);
                courseHasError = true;
                continue;
            }
            if (!uniquePrerequisites.insert(prerequisite).second) {
                report.errors.push_back(sourceName + ": line " +
                                        std::to_string(lineNumber) +
                                        " repeats prerequisite " + prerequisite);
                courseHasError = true;
                continue;
            }
            course.prerequisites.push_back(prerequisite);
        }

        if (!courseHasError) {
            candidate.emplace(course.number, std::move(course));
        }
    }

    if (candidate.empty() && report.errors.empty()) {
        report.errors.push_back(sourceName + ": no course records were found");
    }

    for (const auto& entry : candidate) {
        for (const std::string& prerequisite : entry.second.prerequisites) {
            if (candidate.find(prerequisite) == candidate.end()) {
                report.errors.push_back(entry.first +
                                        " references missing prerequisite " +
                                        prerequisite);
            }
        }
    }

    if (!report.errors.empty()) {
        return report;
    }

    courses_ = std::move(candidate);
    buildGraph();

    std::vector<std::string> cycle;
    if (hasCycle(&cycle)) {
        report.errors.push_back("Prerequisite cycle detected: " + joinCycle(cycle));
        clear();
        return report;
    }

    report.success = true;
    report.coursesLoaded = courses_.size();
    return report;
}

void CourseCatalog::buildGraph() {
    dependents_.clear();
    inDegree_.clear();

    for (const auto& entry : courses_) {
        dependents_[entry.first];
        inDegree_[entry.first] = entry.second.prerequisites.size();
    }

    for (const auto& entry : courses_) {
        for (const std::string& prerequisite : entry.second.prerequisites) {
            dependents_[prerequisite].push_back(entry.first);
        }
    }

    for (auto& entry : dependents_) {
        std::sort(entry.second.begin(), entry.second.end());
    }
}

const Course* CourseCatalog::findCourse(const std::string& courseNumber) const {
    const std::string normalized = normalizeCourseNumber(courseNumber);
    const auto match = courses_.find(normalized);
    return match == courses_.end() ? nullptr : &match->second;
}

std::vector<Course> CourseCatalog::sortedCourses() const {
    std::vector<Course> result;
    result.reserve(courses_.size());
    for (const auto& entry : courses_) {
        result.push_back(entry.second);
    }
    std::sort(result.begin(), result.end(),
              [](const Course& left, const Course& right) {
                  return left.number < right.number;
              });
    return result;
}

bool CourseCatalog::hasCycle(std::vector<std::string>* cyclePath) const {
    std::unordered_map<std::string, int> state;
    std::vector<std::string> stack;

    std::vector<std::string> vertices;
    vertices.reserve(courses_.size());
    for (const auto& entry : courses_) {
        vertices.push_back(entry.first);
        state[entry.first] = 0;
    }
    std::sort(vertices.begin(), vertices.end());

    std::function<bool(const std::string&)> visit =
        [&](const std::string& vertex) -> bool {
        state[vertex] = 1;
        stack.push_back(vertex);

        const auto adjacency = dependents_.find(vertex);
        if (adjacency != dependents_.end()) {
            for (const std::string& neighbor : adjacency->second) {
                if (state[neighbor] == 0 && visit(neighbor)) {
                    return true;
                }
                if (state[neighbor] == 1) {
                    if (cyclePath != nullptr) {
                        const auto begin =
                            std::find(stack.begin(), stack.end(), neighbor);
                        cyclePath->assign(begin, stack.end());
                        cyclePath->push_back(neighbor);
                    }
                    return true;
                }
            }
        }

        stack.pop_back();
        state[vertex] = 2;
        return false;
    };

    for (const std::string& vertex : vertices) {
        if (state[vertex] == 0 && visit(vertex)) {
            return true;
        }
    }
    return false;
}

std::vector<std::string> CourseCatalog::topologicalOrder(std::string* error) const {
    std::vector<std::string> order;
    if (courses_.empty()) {
        if (error != nullptr) {
            *error = "Course data has not been loaded.";
        }
        return order;
    }

    std::unordered_map<std::string, std::size_t> remaining = inDegree_;
    std::priority_queue<std::string,
                        std::vector<std::string>,
                        std::greater<std::string>> ready;

    for (const auto& entry : remaining) {
        if (entry.second == 0) {
            ready.push(entry.first);
        }
    }

    while (!ready.empty()) {
        const std::string current = ready.top();
        ready.pop();
        order.push_back(current);

        const auto adjacency = dependents_.find(current);
        if (adjacency == dependents_.end()) {
            continue;
        }
        for (const std::string& dependent : adjacency->second) {
            std::size_t& degree = remaining[dependent];
            if (degree > 0) {
                --degree;
                if (degree == 0) {
                    ready.push(dependent);
                }
            }
        }
    }

    if (order.size() != courses_.size()) {
        order.clear();
        if (error != nullptr) {
            *error = "A valid course order cannot be produced because the graph contains a cycle.";
        }
    }
    return order;
}

std::size_t CourseCatalog::size() const noexcept {
    return courses_.size();
}

bool CourseCatalog::empty() const noexcept {
    return courses_.empty();
}

}  // namespace advising

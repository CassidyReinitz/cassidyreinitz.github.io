#include "CourseCatalog.h"
#include "InputValidation.h"

#include <algorithm>
#include <functional>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

namespace {

const char* VALID_DATA =
    "CSCI100,Introduction to Programming\n"
    "CSCI200,Data Structures,CSCI100\n"
    "MATH100,College Mathematics\n"
    "CSCI300,Algorithms,CSCI200,MATH100\n"
    "CSCI310,Software Engineering,CSCI200\n";

void require(bool condition, const std::string& message) {
    if (!condition) {
        throw std::runtime_error(message);
    }
}

advising::CourseCatalog loadValidCatalog() {
    advising::CourseCatalog catalog;
    std::istringstream input(VALID_DATA);
    const advising::LoadReport report = catalog.loadFromStream(input, "valid-data");
    require(report.success, "valid catalog should load");
    return catalog;
}

void testValidCatalogLoads() {
    const advising::CourseCatalog catalog = loadValidCatalog();
    require(catalog.size() == 5, "five courses should load");
}

void testAverageConstantTimeLookupAndNormalization() {
    const advising::CourseCatalog catalog = loadValidCatalog();
    const advising::Course* course = catalog.findCourse("  csci 300 ");
    require(course != nullptr, "mixed-case normalized lookup should succeed");
    require(course->title == "Algorithms", "lookup should return correct course");
}

void testSortedCourseList() {
    const advising::CourseCatalog catalog = loadValidCatalog();
    const std::vector<advising::Course> sorted = catalog.sortedCourses();
    require(std::is_sorted(sorted.begin(), sorted.end(),
                           [](const advising::Course& left,
                              const advising::Course& right) {
                               return left.number < right.number;
                           }),
            "course list should be sorted by course number");
}

void testTopologicalOrderRespectsPrerequisites() {
    const advising::CourseCatalog catalog = loadValidCatalog();
    std::string error;
    const std::vector<std::string> order = catalog.topologicalOrder(&error);
    require(error.empty(), "valid graph should produce no ordering error");
    require(order.size() == catalog.size(), "all courses should be scheduled");

    std::unordered_map<std::string, std::size_t> position;
    for (std::size_t i = 0; i < order.size(); ++i) {
        position[order[i]] = i;
    }
    for (const advising::Course& course : catalog.sortedCourses()) {
        for (const std::string& prerequisite : course.prerequisites) {
            require(position[prerequisite] < position[course.number],
                    prerequisite + " must appear before " + course.number);
        }
    }
}

void testQuotedCommaInTitle() {
    advising::CourseCatalog catalog;
    std::istringstream input("CSCI100,\"Programming, Logic, and Design\"\n");
    const advising::LoadReport report = catalog.loadFromStream(input, "quoted");
    require(report.success, "quoted CSV title should load");
    require(catalog.findCourse("CSCI100")->title ==
                "Programming, Logic, and Design",
            "quoted comma should remain in title");
}

void testDuplicateCourseRejected() {
    advising::CourseCatalog catalog;
    std::istringstream input(
        "CSCI100,First Title\nCSCI100,Duplicate Title\n");
    const advising::LoadReport report = catalog.loadFromStream(input, "duplicate");
    require(!report.success, "duplicate course should be rejected");
    require(catalog.empty(), "failed loads should not leave partial data");
}

void testMissingPrerequisiteRejected() {
    advising::CourseCatalog catalog;
    std::istringstream input("CSCI200,Data Structures,CSCI100\n");
    const advising::LoadReport report = catalog.loadFromStream(input, "missing");
    require(!report.success, "missing prerequisite should be rejected");
}

void testCycleRejected() {
    advising::CourseCatalog catalog;
    std::istringstream input(
        "CSCI100,First,CSCI300\n"
        "CSCI200,Second,CSCI100\n"
        "CSCI300,Third,CSCI200\n");
    const advising::LoadReport report = catalog.loadFromStream(input, "cycle");
    require(!report.success, "cycle should be rejected");
    require(!report.errors.empty(), "cycle should produce a useful error");
    require(report.errors.back().find("cycle") != std::string::npos,
            "cycle error should identify the problem");
}

void testMalformedAndEmptyInputsRejected() {
    advising::CourseCatalog malformed;
    std::istringstream malformedInput("not-a-course\n");
    require(!malformed.loadFromStream(malformedInput, "malformed").success,
            "malformed record should be rejected");

    advising::CourseCatalog empty;
    std::istringstream emptyInput("\n  \n");
    require(!empty.loadFromStream(emptyInput, "empty").success,
            "empty file should be rejected");
}

void testMenuInputValidation() {
    require(advising::parseMenuChoice(" 4 ").value_or(-1) == 4,
            "trimmed whole-number choice should be accepted");
    require(!advising::parseMenuChoice("3abc").has_value(),
            "trailing characters should be rejected");
    require(!advising::parseMenuChoice("").has_value(),
            "empty choice should be rejected");
    require(!advising::parseMenuChoice("2.5").has_value(),
            "decimal choice should be rejected");
}

}  // namespace

int main() {
    const std::vector<std::pair<std::string, std::function<void()>>> tests = {
        {"valid catalog loads", testValidCatalogLoads},
        {"hash lookup and normalization", testAverageConstantTimeLookupAndNormalization},
        {"sorted course list", testSortedCourseList},
        {"topological order", testTopologicalOrderRespectsPrerequisites},
        {"quoted CSV title", testQuotedCommaInTitle},
        {"duplicate rejection", testDuplicateCourseRejected},
        {"missing prerequisite rejection", testMissingPrerequisiteRejected},
        {"cycle rejection", testCycleRejected},
        {"malformed and empty input rejection", testMalformedAndEmptyInputsRejected},
        {"menu input validation", testMenuInputValidation},
    };

    std::size_t passed = 0;
    for (const auto& test : tests) {
        try {
            test.second();
            ++passed;
            std::cout << "[PASS] " << test.first << '\n';
        } catch (const std::exception& error) {
            std::cout << "[FAIL] " << test.first << ": " << error.what() << '\n';
        }
    }

    std::cout << "\n" << passed << " of " << tests.size() << " tests passed.\n";
    return passed == tests.size() ? 0 : 1;
}

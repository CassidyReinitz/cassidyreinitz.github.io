#include "CourseCatalog.h"
#include <algorithm>
#include <chrono>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>
using Clock = std::chrono::steady_clock;
std::string id(std::size_t i) { return "CS" + std::to_string(1000 + i); }
struct Dataset { std::string text; std::vector<std::vector<std::size_t>> prerequisites; std::size_t edges = 0; };
Dataset generate(std::size_t count, const std::string& shape) {
    Dataset d; d.prerequisites.resize(count); std::ostringstream out;
    for (std::size_t i=0; i<count; ++i) {
        out << id(i) << ",Course " << i;
        if (shape=="dense") {
            for (std::size_t j=0; j<i; ++j) d.prerequisites[i].push_back(j);
        } else if (shape=="chain") {
            if (i>0) d.prerequisites[i].push_back(i-1);
        } else if (shape=="wide") {
            if (i>0) d.prerequisites[i].push_back(0);
        } else {
            for (std::size_t distance: {1U, 3U, 11U})
                if (i>=distance) d.prerequisites[i].push_back(i-distance);
        }
        for (auto j: d.prerequisites[i]) { out << ',' << id(j); ++d.edges; }
        out << '\n';
    }
    d.text=out.str(); return d;
}
double elapsed(Clock::time_point start) {return std::chrono::duration<double,std::milli>(Clock::now()-start).count();}
double median(std::vector<double> values) {std::sort(values.begin(),values.end());return values[values.size()/2];}
void verify(const Dataset& data,const std::vector<std::string>& order) {
    if(order.size()!=data.prerequisites.size()) throw std::runtime_error("Incorrect schedule size");
    std::unordered_map<std::string,std::size_t> positions;
    for(std::size_t i=0;i<order.size();++i) if(!positions.emplace(order[i],i).second) throw std::runtime_error("Duplicate course");
    for(std::size_t i=0;i<data.prerequisites.size();++i)
        for(auto j:data.prerequisites[i])
            if(positions.at(id(j))>=positions.at(id(i))) throw std::runtime_error("Prerequisite violated");
}
void run(std::size_t count,const std::string& shape) {
    const auto data=generate(count,shape);
    std::vector<double> loads,cycles,sorts,lookups;std::vector<std::string> first;
    for(int repeat=0;repeat<3;++repeat) {
        advising::CourseCatalog catalog;std::istringstream input(data.text);
        auto t=Clock::now();auto report=catalog.loadFromStream(input,"generated");loads.push_back(elapsed(t));
        if(!report.success||catalog.size()!=count) throw std::runtime_error("Load failed");
        t=Clock::now();bool cyclic=catalog.hasCycle();cycles.push_back(elapsed(t));
        if(cyclic)throw std::runtime_error("DAG classified as cyclic");
        t=Clock::now();auto order=catalog.topologicalOrder();sorts.push_back(elapsed(t));
        verify(data,order);
        if(repeat==0) first=order;else if(first!=order)throw std::runtime_error("Nondeterministic ordering");
        // Prepare keys outside timing; validate every lookup so the optimizer cannot discard work.
        std::vector<std::string> keys;keys.reserve(10000);
        for(std::size_t i=0;i<10000;++i)keys.push_back(id(i%count));
        t=Clock::now();std::size_t found=0;
        for(const auto& key:keys) {auto c=catalog.findCourse(key);if(c&&c->number==key)++found;}
        lookups.push_back(elapsed(t));if(found!=10000)throw std::runtime_error("Lookup mismatch");
    }
    std::cout<<shape<<','<<count<<','<<data.edges<<",3,"<<std::fixed<<std::setprecision(3)
             <<median(loads)<<','<<median(cycles)<<','<<median(sorts)<<','<<median(lookups)<<",PASS\n";
}
int main() {
    try {
        std::cout<<"shape,vertices,edges,repetitions,load_median_ms,cycle_median_ms,topological_median_ms,lookup_10000_median_ms,validation\n";
        for(auto n:{250U,1000U,4000U})for(const std::string shape:{"sparse","chain","wide"})run(n,shape);
        for(auto n:{250U,500U,1000U})run(n,"dense");
        // Large cycle: last course points back to the first; invalid load must leave no partial catalog.
        auto cyclic=generate(4000,"chain");auto newline=cyclic.text.find('\n');
        cyclic.text.insert(newline,","+id(3999));advising::CourseCatalog catalog;std::istringstream input(cyclic.text);
        auto report=catalog.loadFromStream(input,"large-cycle");
        if(report.success||!catalog.empty()||report.errors.empty())throw std::runtime_error("Large cycle not safely rejected");
        std::cerr<<"PASS large cycle rejection: 4000 vertices, 4000 edges\n";
    }catch(const std::exception& e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}
}

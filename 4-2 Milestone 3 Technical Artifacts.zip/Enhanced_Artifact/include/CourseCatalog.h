#ifndef ADVISING_COURSE_CATALOG_H
#define ADVISING_COURSE_CATALOG_H

#include <cstddef>
#include <istream>
#include <string>
#include <unordered_map>
#include <vector>

namespace advising {

struct Course {
    std::string number;
    std::string title;
    std::vector<std::string> prerequisites;
};

struct LoadReport {
    bool success = false;
    std::size_t coursesLoaded = 0;
    std::vector<std::string> errors;
};

class CourseCatalog {
public:
    LoadReport loadFromFile(const std::string& filename);
    LoadReport loadFromStream(std::istream& input,
                              const std::string& sourceName = "input");

    const Course* findCourse(const std::string& courseNumber) const;
    std::vector<Course> sortedCourses() const;
    std::vector<std::string> topologicalOrder(std::string* error = nullptr) const;
    bool hasCycle(std::vector<std::string>* cyclePath = nullptr) const;

    std::size_t size() const noexcept;
    bool empty() const noexcept;

    static std::string normalizeCourseNumber(const std::string& value);

private:
    std::unordered_map<std::string, Course> courses_;
    std::unordered_map<std::string, std::vector<std::string>> dependents_;
    std::unordered_map<std::string, std::size_t> inDegree_;

    void clear() noexcept;
    void buildGraph();
};

}  // namespace advising

#endif

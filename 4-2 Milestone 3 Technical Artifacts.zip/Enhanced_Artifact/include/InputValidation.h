#ifndef ADVISING_INPUT_VALIDATION_H
#define ADVISING_INPUT_VALIDATION_H

#include <cctype>
#include <optional>
#include <string>

namespace advising {

inline std::string trimInput(const std::string& value) {
    std::size_t begin = 0;
    while (begin < value.size() &&
           std::isspace(static_cast<unsigned char>(value[begin])) != 0) {
        ++begin;
    }

    std::size_t end = value.size();
    while (end > begin &&
           std::isspace(static_cast<unsigned char>(value[end - 1])) != 0) {
        --end;
    }
    return value.substr(begin, end - begin);
}

inline std::optional<int> parseMenuChoice(const std::string& value) {
    const std::string trimmed = trimInput(value);
    if (trimmed.empty()) {
        return std::nullopt;
    }

    std::size_t consumed = 0;
    try {
        const int result = std::stoi(trimmed, &consumed);
        if (consumed != trimmed.size()) {
            return std::nullopt;
        }
        return result;
    } catch (...) {
        return std::nullopt;
    }
}

}  // namespace advising

#endif

# Advising Assistance Program Enhanced Version

This C++17 enhancement converts the original CS 300 course planner into a validated prerequisite-graph application. It keeps fast course lookup in an `unordered_map`, represents prerequisite relationships with an adjacency list, detects cycles with depth-first search, and generates a prerequisite-respecting schedule with Kahn's topological-sort algorithm.

## Enhancement Summary

- Replaced global mutable state with a reusable `CourseCatalog` class.
- Added normalized average O(1) hash lookup by course number.
- Added quoted-field-aware CSV parsing and transactional validation.
- Rejects malformed records, invalid identifiers, duplicates, repeated prerequisites, missing prerequisite references, empty files, and cycles.
- Stores prerequisite-to-dependent edges in an adjacency-list graph.
- Uses DFS to report circular prerequisite chains.
- Uses a min-priority queue with Kahn's algorithm to produce deterministic topological output.
- Uses `getline` and strict whole-number parsing so invalid menu input cannot leave the input stream in a failed state.
- Includes ten dependency-free automated tests and representative valid and invalid datasets.

## Build and Test

The project requires a C++17 compiler and `make`.

```bash
make
make check
```

Run the program from the `Enhanced_Artifact` directory:

```bash
./build/course_planner
```

Choose option 1 and enter:

```text
data/valid_courses.csv
```

## Complexity Analysis

Let V be the number of courses and E be the number of prerequisite relationships.

| Operation | Expected Complexity | Rationale |
| --- | --- | --- |
| Course insertion and lookup | O(1) average | Courses are keyed by normalized identifier in an `unordered_map`. |
| Alphabetical display | O(V log V) | The values are copied and sorted for presentation. |
| Graph construction | O(V + E) | Each course and prerequisite relationship is processed once. |
| DFS cycle detection | O(V + E) | Each vertex and directed edge is visited at most once. |
| Topological sorting | O((V + E) log V) | Kahn's algorithm processes V and E, while the min-priority queue makes deterministic selections in O(log V). A FIFO queue would provide O(V + E), but output among simultaneously available courses would depend on hash iteration order. |
| Graph storage | O(V + E) | The hash maps and adjacency lists store vertices and edges. |

## Design Trade-offs

An ordered `map` would keep keys sorted but would make lookup O(log V). The enhanced design favors average O(1) lookup with an `unordered_map`, then sorts only when the interface requests an alphabetical list. The adjacency list uses less space than a V-by-V matrix for a sparse prerequisite graph. The min-priority queue adds a logarithmic factor to topological sorting, but it ensures stable, reproducible ordering when multiple courses are available at the same time.

## Security and Reliability

The loader validates all records into temporary storage and commits the catalog only if the entire dataset is valid. This prevents partially loaded or contradictory data from influencing advising output. Course identifiers are normalized and allowlisted by format, errors avoid exposing memory or implementation details, menu input is strictly parsed, and graph validation prevents cyclic requirements from producing a misleading schedule.

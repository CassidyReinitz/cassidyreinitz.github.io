CS 499 Milestone Three Technical Artifact
Enhancement Two: Algorithms and Data Structure
Student: Cassidy Reinitz

Original_Artifact contains the unchanged CS 300 portfolio source used as the baseline.

Enhanced_Artifact contains the completed C++17 enhancement, automated tests, sample
datasets, complexity and design documentation, verification results, and the generative
AI acknowledgment.

To build and test the enhanced artifact:

1. Open a terminal in Enhanced_Artifact.
2. Run: make
3. Run: make check
4. Run: ./build/course_planner
5. Choose option 1 and enter: data/valid_courses.csv

The accompanying enhancement narrative is submitted as a separate Word document, as
required by the Milestone Three instructions.

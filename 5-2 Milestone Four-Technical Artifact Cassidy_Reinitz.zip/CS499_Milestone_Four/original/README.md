CS 340 – Portfolio Reflection
MongoDB Dashboard & CRUD Module Project
How do you write programs that are maintainable, readable, and adaptable?

Writing maintainable and adaptable programs starts with separation of concerns. In Project One, I created a reusable CRUD Python module that handled all database interactions independently from the dashboard interface. Instead of embedding database logic directly inside the dashboard callbacks, I built a dedicated class to manage Create, Read, Update, and Delete operations.

This approach made the code more readable because each component had a clear responsibility:

The CRUD module handled database logic.

The dashboard handled presentation and user interaction.

The advantage of working this way was modularity. When I built the Project Two dashboard, I did not have to rewrite database logic—I simply imported and reused the CRUD module. This made development faster and reduced errors. It also made debugging easier because problems could be isolated to either the database layer or the interface layer.

In the future, I could reuse this CRUD module structure for other MongoDB-backed applications such as analytics dashboards, inventory systems, or client reporting tools. The same architecture could scale into larger full-stack applications where a middleware layer connects front-end components to a database.

How do you approach a problem as a computer scientist?

When approaching the Grazioso Salvare database and dashboard requirements, I started by analyzing the problem in layers. Instead of jumping straight into coding, I first asked:

What data is required?

How will it be queried?

What filters and aggregations are needed?

How will the user interact with the system?

This layered thinking helped me break the project into manageable pieces:

Structure the database properly.

Create efficient queries.

Build reusable CRUD functionality.

Connect that functionality to the dashboard interface.

This differed from earlier coursework where assignments were often smaller and more isolated. In this project, I had to think about system architecture, data flow, and user interaction simultaneously. It required more planning and systems thinking rather than just solving a single programming task.

In future projects, I would continue using this layered strategy. I would also invest more time in early planning, including diagramming data flows and designing query strategies before writing code. That reduces rework later and leads to cleaner solutions.

What do computer scientists do, and why does it matter?

Computer scientists design systems that transform data into usable information. In this project, the raw dataset by itself had limited value. By creating structured queries, aggregation pipelines, and an interactive dashboard, I turned that data into actionable insights. For a company like Grazioso Salvare, this matters because:
They can quickly filter data to find relevant animal outcomes.
They can visualize patterns and trends.
They can make data-driven decisions instead of relying on manual record review.
In a broader sense, computer scientists build tools that improve efficiency, reduce human error, and enable organizations to operate strategically rather than reactively. The ability to design scalable database systems and connect them to user-friendly dashboards directly supports business intelligence and operational effectiveness.
This project demonstrated how backend systems and frontend interfaces work together to support real-world decision-making.

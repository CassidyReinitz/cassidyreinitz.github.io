"""
CRUD_Python_Module.py

This module defines the AnimalShelter class, which provides
Create, Read, Update, and Delete (CRUD) operations for the
Austin Animal Center (AAC) animals collection in MongoDB.
"""

from pymongo import MongoClient
from pymongo.errors import PyMongoError


class AnimalShelter:
    """
    CRUD operations for the AAC animals collection in MongoDB.
    """

    def __init__(
        self,
        username: str,
        password: str,
        host: str = "localhost",
        port: int = 27017,
        db_name: str = "aac",
        collection_name: str = "animals",
    ) -> None:
        """
        Initialize the connection to MongoDB and set the database and collection.

        :param username: MongoDB username (e.g., aacuser)
        :param password: MongoDB password
        :param host: MongoDB host (default: localhost)
        :param port: MongoDB port (default: 27017)
        :param db_name: Name of the database (default: aac)
        :param collection_name: Name of the collection (default: animals)
        """
        try:
            # Build the MongoDB URI. Note the db_name at the end of the URI.
            uri = f"mongodb://{username}:{password}@{host}:{port}/{db_name}?authSource=admin"
            self.client = MongoClient(uri)
            self.database = self.client[db_name]
            self.collection = self.database[collection_name]
        except PyMongoError as error:
            print(f"Error connecting to MongoDB: {error}")
            raise

    # ------------------------------------------------------------------
    # CREATE
    # ------------------------------------------------------------------
    def create(self, data: dict) -> bool:
        """
        Insert a document into the collection.

        :param data: Document to insert as a dictionary.
        :return: True if insert is successful, otherwise False.
        """
        if data is None or not isinstance(data, dict) or not data:
            raise ValueError("Data must be a non-empty dictionary.")

        try:
            result = self.collection.insert_one(data)
            return result.inserted_id is not None
        except PyMongoError as error:
            print(f"Error inserting document: {error}")
            return False

    # ------------------------------------------------------------------
    # READ
    # ------------------------------------------------------------------
    def read(self, query: dict, projection: dict = None) -> list:
        """
        Query for document(s) in the collection using find().

        :param query: Dictionary representing the MongoDB query filter.
                      Use {} to return all documents.
        :param projection: Optional dictionary specifying fields to include/exclude.
        :return: List of documents that match the query. Empty list on error.
        """

        if query is None or not isinstance(query, dict):
            raise ValueError("Query must be a dictionary (use {} for all documents).")

        try:
            if projection:
                cursor = self.collection.find(query, projection)
            else:
                cursor = self.collection.find(query)

            return list(cursor)

        except PyMongoError as error:
            print(f"Error reading documents: {error}")
            return []

    # ------------------------------------------------------------------
    # UPDATE
    # ------------------------------------------------------------------
    def update(self, query: dict, new_values: dict) -> int:
        """
        Update document(s) that match the query.

        :param query: Dictionary representing the MongoDB query filter.
        :param new_values: Dictionary of fields to update (without $set).
        :return: Number of documents modified.
        """
        if query is None or not isinstance(query, dict) or not query:
            raise ValueError("Query must be a non-empty dictionary.")

        if new_values is None or not isinstance(new_values, dict) or not new_values:
            raise ValueError("new_values must be a non-empty dictionary.")

        try:
            update_document = {"$set": new_values}
            result = self.collection.update_many(query, update_document)
            return result.modified_count
        except PyMongoError as error:
            print(f"Error updating documents: {error}")
            return 0

    # ------------------------------------------------------------------
    # DELETE
    # ------------------------------------------------------------------
    def delete(self, query: dict) -> int:
        """
        Delete document(s) that match the query.

        :param query: Dictionary representing the MongoDB query filter.
        :return: Number of documents deleted.
        """
        if query is None or not isinstance(query, dict) or not query:
            raise ValueError("Query must be a non-empty dictionary.")

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except PyMongoError as error:
            print(f"Error deleting documents: {error}")
            return 0


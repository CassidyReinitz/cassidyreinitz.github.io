"""Server-paged Dash interface for the enhanced Grazioso Salvare database service."""

import math
from dash import Dash, Input, Output, State, dcc, html, dash_table
import plotly.express as px
import plotly.graph_objects as go
from CRUD_Python_Module import AnimalShelter, DataAccessError
from rescue_queries import LABELS

DISPLAY_COLUMNS = [
    ("Animal ID", "animal_id"),
    ("Type", "animal_type"),
    ("Breed", "breed"),
    ("Name", "name"),
    ("Sex", "sex_upon_outcome"),
    ("Age in weeks", "age_upon_outcome_in_weeks"),
]


def empty_chart(message):
    figure = go.Figure()
    figure.add_annotation(
        text=message, x=0.5, y=0.5, xref="paper", yref="paper", showarrow=False
    )
    return figure


def load_view(store, category, page, page_size, sorting):
    """Pure callback helper, also exercised by database integration tests."""
    field = sorting[0]["column_id"] if sorting else "animal_id"
    direction = -1 if sorting and sorting[0]["direction"] == "desc" else 1
    result = store.page(category, page, page_size, field, direction)
    counts = store.summary(category)
    figure = (
        px.bar(
            counts,
            x="breed",
            y="count",
            title="Breed counts across all matching records",
        )
        if counts
        else empty_chart("No matching animals")
    )
    figure.update_layout(
        xaxis_title="Breed", yaxis_title="Records", template="plotly_white"
    )
    return (
        result["records"],
        result["page_count"],
        f"{result['total']} matching records. Page {page + 1} of {max(1, result['page_count'])}.",
        figure,
    )


def selected_location(rows, selected):
    if not rows:
        return empty_chart("No matching animals")
    row = rows[selected[0]] if selected and 0 <= selected[0] < len(rows) else rows[0]
    lat, lon = row.get("location_lat"), row.get("location_long")
    if (
        not isinstance(lat, (int, float))
        or not isinstance(lon, (int, float))
        or not math.isfinite(lat)
        or not math.isfinite(lon)
        or not (-90 <= lat <= 90 and -180 <= lon <= 180)
    ):
        return empty_chart("Location unavailable for this record")
    # OpenStreetMap tiles require internet; no API key or secret is embedded.
    figure = go.Figure(
        go.Scattermap(
            lat=[lat],
            lon=[lon],
            mode="markers",
            text=[row.get("name") or "Unnamed animal"],
        )
    )
    figure.update_layout(
        map={
            "style": "open-street-map",
            "center": {"lat": lat, "lon": lon},
            "zoom": 10,
        },
        title="Selected animal location",
        margin={"l": 0, "r": 0, "b": 0, "t": 40},
    )
    return figure


def create_app(store):
    app = Dash(__name__)
    app.layout = html.Main(
        [
            html.H1("Grazioso Salvare Rescue Animal Dashboard"),
            html.P("Cassidy Reinitz — CS 499 database enhancement"),
            html.Label("Rescue category", htmlFor="rescue"),
            dcc.Dropdown(
                id="rescue",
                options=[
                    {"label": label, "value": key} for key, label in LABELS.items()
                ],
                value="reset",
                clearable=False,
            ),
            html.Div(id="status", role="status", **{"aria-live": "polite"}),
            dash_table.DataTable(
                id="animals",
                columns=[{"name": label, "id": key} for label, key in DISPLAY_COLUMNS],
                data=[],
                page_current=0,
                page_size=10,
                page_action="custom",
                page_count=0,
                sort_action="custom",
                sort_mode="single",
                sort_by=[],
                row_selectable="single",
                selected_rows=[],
                style_table={"overflowX": "auto"},
                style_cell={"textAlign": "left", "padding": "8px"},
            ),
            dcc.Graph(id="summary"),
            dcc.Graph(id="location"),
            html.P(
                "Candidate categories can overlap. Records are screening candidates, not confirmed rescue suitability."
            ),
        ],
        style={
            "maxWidth": "1100px",
            "margin": "auto",
            "fontFamily": "Arial, sans-serif",
        },
    )

    @app.callback(
        Output("animals", "data"),
        Output("animals", "page_count"),
        Output("status", "children"),
        Output("summary", "figure"),
        Output("animals", "page_current"),
        Output("animals", "selected_rows"),
        Input("rescue", "value"),
        Input("animals", "page_current"),
        Input("animals", "page_size"),
        Input("animals", "sort_by"),
    )
    def refresh(category, page, size, sorting):
        try:
            rows, count, message, figure = load_view(
                store, category, page, size, sorting
            )
            # When a filter shrinks the result set, move to a valid page immediately.
            if page >= max(1, count):
                page = 0
                rows, count, message, figure = load_view(
                    store, category, page, size, sorting
                )
            return rows, count, message, figure, page, []
        except (ValueError, DataAccessError):
            return (
                [],
                0,
                "Could not load records. Check the selected filter or contact the administrator.",
                empty_chart("Data unavailable"),
                0,
                [],
            )

    @app.callback(
        Output("location", "figure"),
        Input("animals", "data"),
        Input("animals", "selected_rows"),
    )
    def location(rows, selected):
        return selected_location(rows, selected)

    return app


if __name__ == "__main__":
    store = AnimalShelter()
    try:
        create_app(store).run(host="127.0.0.1", port=8050, debug=False)
    finally:
        store.close()

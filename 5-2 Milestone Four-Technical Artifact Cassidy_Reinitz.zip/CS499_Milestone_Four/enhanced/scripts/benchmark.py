"""Real query-plan comparison using explicitly synthetic AAC-like data."""

from statistics import median
from time import perf_counter
from rescue_queries import build_query
from validation import INDEXES


def synthetic_animals(count=30000):
    for i in range(count):
        candidate = i % 100 == 0
        yield {
            "animal_id": f"A{i:06d}",
            "animal_type": "Dog" if candidate else "Cat",
            "breed": (
                "Labrador Retriever Mix" if candidate else "Domestic Shorthair Mix"
            ),
            "sex_upon_outcome": "Intact Female",
            "age_upon_outcome_in_weeks": 52,
            "name": f"Synthetic animal {i}",
            "location_lat": 30.2672,
            "location_long": -97.7431,
        }


def stages(plan):
    if isinstance(plan, dict):
        return ([plan["stage"]] if "stage" in plan else []) + [
            s for v in plan.values() for s in stages(v)
        ]
    if isinstance(plan, list):
        return [s for v in plan for s in stages(v)]
    return []


def explain(db, query, hint=None):
    command = {
        "find": "animals",
        "filter": query,
        "sort": {"animal_id": 1, "_id": 1},
        "limit": 10,
    }
    if hint:
        command["hint"] = hint
    r = db.command("explain", command, verbosity="executionStats")
    s = r["executionStats"]
    return {
        "stages": sorted(set(stages(r["queryPlanner"]["winningPlan"]))),
        "returned": s["nReturned"],
        "documents_examined": s["totalDocsExamined"],
        "keys_examined": s["totalKeysExamined"],
        "execution_ms": s["executionTimeMillis"],
    }


def benchmark(db):
    if not db.name.startswith("cs499_test_"):
        raise ValueError("Only disposable cs499_test_ databases are allowed.")
    db.animals.delete_many({})
    db.animals.drop_indexes()
    db.animals.insert_many(list(synthetic_animals()))
    q = build_query("water")
    before = explain(db, q)

    def identities():
        return [
            r["_id"]
            for r in db.animals.find(q).sort([("animal_id", 1), ("_id", 1)]).limit(10)
        ]

    expected = identities()
    for name, keys in INDEXES:
        db.animals.create_index(keys, name=name)
    after = explain(db, q)
    hinted = explain(db, q, "rescue_candidates")
    assert identities() == expected

    def timing(paged):
        values = []
        for i in range(7):
            start = perf_counter()
            cursor = db.animals.find(q).sort([("animal_id", 1), ("_id", 1)])
            rows = list(cursor.limit(10) if paged else cursor)
            values.append((perf_counter() - start) * 1000)
        return {
            "records_materialized": len(rows),
            "median_ms": round(median(values), 3),
        }

    return {
        "fixture": "30000 synthetic AAC-like records; not original shelter data",
        "mongodb_version": db.client.server_info()["version"],
        "matching_records": db.animals.count_documents(q),
        "before_indexes": before,
        "after_indexes_optimizer": after,
        "after_indexes_candidate_hint": hinted,
        "result_identity_verified": True,
        "unbounded_read": timing(False),
        "paged_read": timing(True),
        "notes": [
            "Local timing is informational, not a production guarantee.",
            "Skip costs grow with offset; separate page and count reads are not a concurrent snapshot.",
            "Hints are diagnostic only; application queries use optimizer selection.",
        ],
    }

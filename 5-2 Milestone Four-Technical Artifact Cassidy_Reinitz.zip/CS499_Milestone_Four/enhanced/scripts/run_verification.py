"""Disposable real MongoDB integration suite. Credentials generated in memory."""

import argparse, io, json, os, secrets, socket, subprocess, tempfile, time, unittest
from pathlib import Path
from urllib.parse import quote_plus
from pymongo import MongoClient
from scripts.setup_database import configure_database, provision_roles
from scripts.benchmark import benchmark

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mongod", required=True)
    parser.add_argument("--evidence", default="../evidence")
    args = parser.parse_args()
    evidence = Path(args.evidence).resolve()
    evidence.mkdir(parents=True, exist_ok=True)
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    with tempfile.TemporaryDirectory(prefix="cs499_mongo_") as tmp:
        proc = subprocess.Popen(
            [
                str(Path(args.mongod).resolve()),
                "--auth",
                "--nounixsocket",
                "--setParameter",
                "diagnosticDataCollectionEnabled=false",
                "--bind_ip",
                "127.0.0.1",
                "--port",
                str(port),
                "--dbpath",
                tmp,
                "--logpath",
                str(Path(tmp) / "mongod.log"),
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        admin = None
        try:
            initial = MongoClient(
                f"mongodb://127.0.0.1:{port}", serverSelectionTimeoutMS=500
            )
            for i in range(50):
                try:
                    initial.admin.command("ping")
                    break
                except Exception:
                    if proc.poll() is not None:
                        raise RuntimeError("MongoDB startup failed.")
                    time.sleep(0.1)
            password = secrets.token_urlsafe(32)
            initial.admin.command(
                "createUser",
                "test_admin",
                pwd=password,
                roles=[{"role": "root", "db": "admin"}],
            )
            initial.close()
            admin_uri = (
                f"mongodb://test_admin:{quote_plus(password)}@127.0.0.1:{port}/admin"
            )
            admin = MongoClient(admin_uri)
            name = "cs499_test_" + secrets.token_hex(4)
            db = admin[name]
            configure_database(db)
            reader = secrets.token_urlsafe(32)
            writer = secrets.token_urlsafe(32)
            provision_roles(db, "test_reader", reader, "test_editor", writer)
            os.environ.update(
                TEST_ADMIN_URI=admin_uri,
                TEST_DATABASE=name,
                TEST_READER_URI=f"mongodb://test_reader:{quote_plus(reader)}@127.0.0.1:{port}/{name}?authSource={name}",
                TEST_WRITER_URI=f"mongodb://test_editor:{quote_plus(writer)}@127.0.0.1:{port}/{name}?authSource={name}",
            )
            suite = unittest.defaultTestLoader.discover("tests", pattern="test_*.py")
            stream = io.StringIO()
            r = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
            text = stream.getvalue()
            print(text)
            (evidence / "integration_tests.txt").write_text(text)
            (evidence / "test_summary.json").write_text(
                json.dumps(
                    {
                        "mongodb_version": admin.server_info()["version"],
                        "tests": r.testsRun,
                        "failures": len(r.failures),
                        "errors": len(r.errors),
                        "authenticated_database": True,
                    },
                    indent=2,
                )
            )
            if not r.wasSuccessful():
                raise SystemExit(1)
            metrics = benchmark(db)
            (evidence / "query_plan_comparison.json").write_text(
                json.dumps(metrics, indent=2)
            )
            print(json.dumps(metrics, indent=2))
        finally:
            if admin is not None:
                admin.close()
            proc.terminate()
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()

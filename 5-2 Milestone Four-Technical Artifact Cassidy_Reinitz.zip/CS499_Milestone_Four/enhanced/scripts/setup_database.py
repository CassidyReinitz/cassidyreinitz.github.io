"""Admin-only schema and index migration. Never embed admin credentials in the dashboard."""

import argparse
import json
import os
from pymongo import MongoClient
from validation import VALIDATOR, INDEXES


def configure_database(db):
    if "animals" not in db.list_collection_names():
        db.create_collection(
            "animals",
            validator=VALIDATOR,
            validationLevel="strict",
            validationAction="error",
        )
    else:
        # Read-only assessment before changing rules; invalid records must be corrected explicitly.
        invalid = db.animals.count_documents({"$nor": [VALIDATOR]})
        if invalid:
            raise ValueError(
                f"{invalid} existing records fail validation. Correct them before migration."
            )
        db.command(
            {
                "collMod": "animals",
                "validator": VALIDATOR,
                "validationLevel": "strict",
                "validationAction": "error",
            }
        )
    for name, keys in INDEXES:
        db.animals.create_index(keys, name=name)
    return {"validator": "strict/error", "indexes": [name for name, _ in INDEXES]}


def provision_roles(db, reader_user, reader_password, writer_user, writer_password):
    roles = [
        ("rescueReader", ["find"]),
        ("rescueEditor", ["find", "insert", "update", "remove"]),
    ]
    for role, actions in roles:
        spec = {
            "privileges": [
                {
                    "resource": {"db": db.name, "collection": "animals"},
                    "actions": actions,
                }
            ],
            "roles": [],
        }
        if db.command("rolesInfo", role)["roles"]:
            db.command("updateRole", role, **spec)
        else:
            db.command("createRole", role, **spec)
    for user, password, role in [
        (reader_user, reader_password, "rescueReader"),
        (writer_user, writer_password, "rescueEditor"),
    ]:
        if db.command("usersInfo", user)["users"]:
            raise ValueError(
                "Account already exists; rotate or modify it explicitly rather than overwrite it."
            )
        db.command(
            "createUser", user, pwd=password, roles=[{"role": role, "db": db.name}]
        )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--provision-users", action="store_true")
    args = parser.parse_args()
    client = MongoClient(os.environ["MONGODB_ADMIN_URI"], serverSelectionTimeoutMS=5000)
    db = client[os.environ.get("MONGODB_DATABASE", "aac")]
    try:
        print(json.dumps(configure_database(db), indent=2))
        if args.provision_users:
            provision_roles(
                db,
                os.environ["MONGODB_READER_USER"],
                os.environ["MONGODB_READER_PASSWORD"],
                os.environ["MONGODB_EDITOR_USER"],
                os.environ["MONGODB_EDITOR_PASSWORD"],
            )
            print("Created collection-scoped reader and editor accounts.")
    finally:
        client.close()

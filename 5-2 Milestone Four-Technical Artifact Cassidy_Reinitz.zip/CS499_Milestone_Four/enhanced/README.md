# Grazioso Salvare database enhancement

Cassidy Reinitz — CS 499 Milestone Four — October 2026

This enhancement extends the original CS 340 Python/MongoDB dashboard into a validated,
bounded database service. It retains the original water, mountain, and disaster candidate
rules. These rules are screening filters, not a certification of an animal's suitability.

## Run the application

Requires Python 3.10+ and MongoDB 8.0+ with authorization enabled. MongoDB 8.0.12 and
Python 3.12 were used for verification. The MongoDB executable is not bundled.

From the `enhanced` directory:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
export PYTHONPATH="$PWD"
```

Supply an administrative URI through `MONGODB_ADMIN_URI` and the intended database name
through `MONGODB_DATABASE` using your environment or secret manager. For a new deployment,
also supply `MONGODB_READER_USER`, `MONGODB_READER_PASSWORD`, `MONGODB_EDITOR_USER`, and
`MONGODB_EDITOR_PASSWORD`. Never paste actual passwords into source files.

```bash
python scripts/setup_database.py --provision-users
```

For an existing database with accounts already provisioned, omit `--provision-users`.
The setup script first checks existing documents against the proposed validator and stops
if any fail. It does not silently coerce or delete historical records. Correct invalid
records explicitly and rerun the migration. Extra historical AAC metadata is allowed by
the MongoDB schema; application writes accept only the documented field allowlist.
The input archive did not include the original shelter dataset, so this migration was
verified on representative synthetic data rather than the original collection.

Set `MONGODB_URI` to the authenticated **reader** connection, then run:

```bash
python dashboard.py
```

Open http://127.0.0.1:8050. `MONGODB_URI` is read from the process environment; `.env.example`
is documentation, not an automatically loaded secret file. Percent-encode reserved characters
in URI passwords. Remote database connections should use TLS. The local verification server
is loopback only. Map tiles need internet; the dashboard does not require the original missing
logo file, JupyterDash, or a proprietary map token.

## Data access and permissions

- `AnimalShelter.page(category, page, page_size, sort_by, direction)` returns at most 100
  projected records, a total count, and page metadata. `_id` breaks sort ties, including
  repeated animal IDs for multiple outcomes. The dashboard requests ten rows at a time.
- `summary(category)` groups all matches by breed in MongoDB, rather than charting only
  the displayed page. `candidate_summary()` uses `$facet` for all three rescue categories.
  Overlapping categories remain separate; their totals should not be added as unique animals.
- `create(document)`, `update(record_id, fields)`, and `delete(record_id)` require an
  authenticated editor account. No role comes from a request, dropdown, or caller-supplied
  string. MongoDB privileges are inspected for a matching collection, and MongoDB also
  enforces permissions if application checks are bypassed.
- Writes validate required fields, permitted categories, finite numeric values, coordinates,
  and text sizes. Operators, unknown fields, internal IDs, and audit fields are rejected.
  Update and delete target one `_id`, not arbitrary bulk filters.
- Delete is a **soft deletion**: `_deleted` and deletion metadata are retained atomically.
  Ordinary reads and summaries exclude the record. Creation and last modification metadata
  live in `_audit`. This is provenance metadata, not an immutable append-only audit ledger.
- The browser is a read-only dashboard. Editor operations are exposed by the Python service,
  not an unauthenticated browser form. Web login and per-person editor UI are out of scope.
  Provenance identifies the authenticated database account, not a separately authenticated
  human using a shared account.
- Driver failures are sanitized; an empty result remains distinguishable from a database failure.

The enhanced DAO deliberately changes the original unrestricted `read(query)` and bulk-write
API. `dashboard.py` is updated to the new contract. The original notebook remains in `original`
as historical coursework rather than being expected to run with the new module unchanged.

## Schema and indexes

`validation.py` defines a shared MongoDB validator and Python write rules. Required fields are
`animal_id`, `animal_type`, `breed`, `sex_upon_outcome`, and `age_upon_outcome_in_weeks`.
Strict validation with error rejection applies to subsequent inserts and updates.

| Index | Keys | Purpose and trade-off |
| --- | --- | --- |
| rescue_candidates | animal_type, breed, age_upon_outcome_in_weeks, _id | Narrow candidate filters; sorting by animal_id can still require SORT. |
| animal_page | animal_id, _id | Stable default page order; animal IDs are not made unique because historical outcomes may repeat. |
| breed_page | breed, _id | Supports breed sorting; other allowed sorts can require in-memory sorting. |

Indexes consume disk space and increase write cost. The benchmark lets the optimizer choose;
it also records a separately hinted diagnostic. No universal latency or complexity improvement
is claimed. Offset pagination is intentionally bounded but becomes more expensive at deep
offsets; cursor pagination is a future improvement. Separate page and count queries are not a
transactional snapshot during concurrent writes. Maximum query time is five seconds.

## Reproduce verification

From `enhanced`, with the MongoDB executable installed:

```bash
export PYTHONPATH="$PWD"
python scripts/run_verification.py --mongod /absolute/path/to/mongod --evidence ../evidence
```

The runner starts a fresh loopback server with authentication, creates random test credentials
in memory, and uses a temporary database directory. It terminates that process and removes
the directory on exit. It does not connect to the database specified by `MONGODB_URI`.
The benchmark refuses any database name outside the generated `cs499_test_` namespace.
Only the ephemeral verification collection has indexes dropped for the before/after experiment.

See `../evidence/integration_tests.txt`, `test_summary.json`, and `query_plan_comparison.json`.
The fixture contains 30,000 synthetic records and 300 water-rescue matches. It is not original
AAC data. Results reflect this machine and dataset. The same first ten record identities were
verified before and after indexing.

## Sources and AI acknowledgment

Implementation decisions were checked against MongoDB's documentation:

- Schema migration: https://www.mongodb.com/docs/manual/core/schema-validation/update-schema-validation/
- Compound indexes: https://www.mongodb.com/docs/manual/core/indexes/index-types/index-compound/
- Query evidence: https://www.mongodb.com/docs/manual/reference/explain-results/
- Roles and privileges: https://www.mongodb.com/docs/manual/reference/built-in-roles/
- Aggregation facets: https://www.mongodb.com/docs/manual/reference/operator/aggregation/facet/

ChatGPT supported inspection, implementation, test development and execution, documentation,
and narrative drafting. The submission distinguishes implemented features, measured results,
and limitations. Original coursework files are preserved separately for comparison.

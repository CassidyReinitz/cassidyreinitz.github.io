import os, unittest
from bson import ObjectId
from pymongo import MongoClient
from pymongo.errors import OperationFailure, WriteError
from unittest.mock import patch
from CRUD_Python_Module import AnimalShelter, DataAccessError, AuthorizationError
from dashboard import create_app, load_view, selected_location


class DatabaseTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.admin = MongoClient(os.environ["TEST_ADMIN_URI"])
        cls.db = cls.admin[os.environ["TEST_DATABASE"]]
        cls.writer = AnimalShelter(os.environ["TEST_WRITER_URI"], cls.db.name)
        cls.reader = AnimalShelter(os.environ["TEST_READER_URI"], cls.db.name)

    @classmethod
    def tearDownClass(cls):
        cls.writer.close()
        cls.reader.close()
        cls.admin.close()

    def setUp(self):
        self.db.animals.delete_many({})
        self.valid = {
            "animal_id": "A100",
            "animal_type": "Dog",
            "breed": "Labrador Retriever Mix",
            "sex_upon_outcome": "Intact Female",
            "age_upon_outcome_in_weeks": 40,
            "name": "Ruby",
            "location_lat": 30.2,
            "location_long": -97.7,
        }

    def test_create_normalizes_and_audits(self):
        rid = self.writer.create({**self.valid, "name": " Ruby "})
        r = self.db.animals.find_one({"_id": ObjectId(rid)})
        self.assertEqual(r["name"], "Ruby")
        self.assertEqual(r["_audit"]["created_by"], "test_editor")

    def test_update_targets_one_and_preserves_audit(self):
        a = self.writer.create(self.valid)
        b = self.writer.create(self.valid)
        before = self.db.animals.find_one({"_id": ObjectId(a)})["_audit"]
        self.assertEqual(self.writer.update(a, {"name": "Lucky"}), 1)
        after = self.db.animals.find_one({"_id": ObjectId(a)})["_audit"]
        self.assertEqual(before["created_at"], after["created_at"])
        self.assertEqual(self.db.animals.find_one({"_id": ObjectId(b)})["name"], "Ruby")

    def test_delete_retains_audit_and_excludes_results(self):
        rid = self.writer.create(self.valid)
        self.assertEqual(self.writer.delete(rid), 1)
        self.assertEqual(self.writer.delete(rid), 0)
        self.assertEqual(self.reader.page()["total"], 0)
        self.assertEqual(self.reader.summary(), [])
        self.assertEqual(
            self.db.animals.find_one({"_id": ObjectId(rid)})["_audit"]["deleted_by"],
            "test_editor",
        )

    def test_reader_denied_service_writes(self):
        for f in [
            lambda: self.reader.create(self.valid),
            lambda: self.reader.update(str(ObjectId()), {"name": "x"}),
            lambda: self.reader.delete(str(ObjectId())),
        ]:
            with self.assertRaises(AuthorizationError):
                f()

    def test_reader_denied_direct_driver_write(self):
        c = MongoClient(os.environ["TEST_READER_URI"])
        try:
            with self.assertRaises(OperationFailure) as e:
                c[self.db.name].animals.insert_one(self.valid)
            self.assertEqual(e.exception.code, 13)
        finally:
            c.close()

    def test_editor_limited_to_animals(self):
        c = MongoClient(os.environ["TEST_WRITER_URI"])
        try:
            with self.assertRaises(OperationFailure):
                c[self.db.name].unrelated.insert_one({"x": 1})
        finally:
            c.close()

    def test_schema_rejects_direct_invalid_writes(self):
        for data in [
            {"animal_id": "A1"},
            {**self.valid, "animal_type": "Robot"},
            {**self.valid, "age_upon_outcome_in_weeks": -1},
            {**self.valid, "location_lat": 91},
        ]:
            with self.assertRaises(WriteError) as e:
                self.db.animals.insert_one(data)
            self.assertEqual(e.exception.code, 121)

    def test_application_validation(self):
        for data in [
            {},
            {**self.valid, "age_upon_outcome_in_weeks": True},
            {**self.valid, "age_upon_outcome_in_weeks": float("nan")},
            {**self.valid, "breed": ""},
            {**self.valid, "name": {"$ne": ""}},
            {**self.valid, "sex_upon_outcome": "invalid"},
        ]:
            with self.assertRaises(ValueError):
                self.writer.create(data)

    def test_operator_and_protected_field_rejection(self):
        for key in ["$set", "_audit", "_deleted", "_id", "name.first"]:
            with self.assertRaises(ValueError):
                self.writer.create({**self.valid, key: "bad"})
        for selection in [{"$where": "true"}, "unsupported", None]:
            with self.assertRaises(ValueError):
                self.reader.page(selection)
        with self.assertRaises(ValueError):
            self.writer.update({}, {"name": "x"})
        with self.assertRaises(ValueError):
            self.writer.delete({})

    def test_paging_and_sort_bounds(self):
        for opt in [
            {"page": -1},
            {"page": True},
            {"page_size": 101},
            {"page_size": 0},
            {"sort_by": "_audit"},
            {"direction": True},
            {"direction": 0},
        ]:
            with self.assertRaises(ValueError):
                self.reader.page(**opt)

    def test_stable_pages_with_duplicate_animal_ids(self):
        for i in range(23):
            self.writer.create(self.valid)
        pages = [self.reader.page(page=i) for i in range(3)]
        ids = [r["id"] for p in pages for r in p["records"]]
        self.assertEqual([len(p["records"]) for p in pages], [10, 10, 3])
        self.assertEqual(len(set(ids)), 23)
        self.assertEqual(
            ids,
            [
                r["id"]
                for p in [self.reader.page(page=i) for i in range(3)]
                for r in p["records"]
            ],
        )
        self.assertEqual(pages[0]["page_count"], 3)

    def test_public_projection(self):
        self.writer.create(self.valid)
        r = self.reader.page()["records"][0]
        self.assertNotIn("_id", r)
        self.assertNotIn("_audit", r)
        self.assertIn("id", r)

    def test_original_filter_boundaries(self):
        for age in [25, 26, 156, 157]:
            self.writer.create({**self.valid, "age_upon_outcome_in_weeks": age})
        self.writer.create({**self.valid, "animal_type": "Cat"})
        self.assertEqual(self.reader.page("water")["total"], 2)
        self.assertEqual(self.reader.page("disaster")["total"], 0)

    def test_summary_covers_all_matches(self):
        for i in range(17):
            self.writer.create(self.valid)
        self.assertEqual(len(self.reader.page("water")["records"]), 10)
        self.assertEqual(
            self.reader.summary("water"),
            [{"breed": "Labrador Retriever Mix", "count": 17}],
        )

    def test_facet_preserves_overlapping_categories(self):
        self.writer.create({**self.valid, "breed": "German Shepherd"})
        r = self.reader.candidate_summary()
        self.assertEqual(r["mountain"][0]["count"], 1)
        self.assertEqual(r["disaster"][0]["count"], 1)
        self.assertEqual(r["water"], [])

    def test_empty_results(self):
        self.assertEqual(self.reader.page()["page_count"], 0)
        self.assertEqual(self.reader.summary(), [])
        self.assertEqual(
            self.reader.candidate_summary(),
            {"water": [], "mountain": [], "disaster": []},
        )

    def test_sanitized_driver_failure(self):
        with patch.object(
            self.writer.collection,
            "insert_one",
            side_effect=OperationFailure("secret internal hostname"),
        ):
            with self.assertRaises(DataAccessError) as e:
                self.writer.create(self.valid)
            self.assertNotIn("secret", str(e.exception))
            self.assertNotIn("hostname", str(e.exception))

    def test_dashboard_callback_and_server(self):
        for i in range(12):
            self.writer.create(self.valid)
        rows, count, message, fig = load_view(self.reader, "water", 0, 10, [])
        self.assertEqual(len(rows), 10)
        self.assertEqual(count, 2)
        self.assertIn("12 matching", message)
        self.assertEqual(list(fig.data[0].y), [12])
        app = create_app(self.reader)
        c = app.server.test_client()
        for endpoint in ["/", "/_dash-layout", "/_dash-dependencies"]:
            self.assertEqual(c.get(endpoint).status_code, 200)
        key = next(k for k in app.callback_map if "page_count" in k)
        outputs = [
            {"id": o.component_id, "property": o.component_property}
            for o in app.callback_map[key]["output"]
        ]
        r = c.post(
            "/_dash-update-component",
            json={
                "output": key,
                "outputs": outputs,
                "changedPropIds": ["rescue.value"],
                "inputs": [
                    {"id": "rescue", "property": "value", "value": "water"},
                    {"id": "animals", "property": "page_current", "value": 99},
                    {"id": "animals", "property": "page_size", "value": 10},
                    {"id": "animals", "property": "sort_by", "value": []},
                ],
                "state": [],
            },
        )
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json["response"]["animals"]["page_current"], 0)
        self.assertEqual(len(r.json["response"]["animals"]["data"]), 10)

    def test_map_with_missing_invalid_and_valid_coordinates(self):
        self.assertTrue(selected_location([], []).layout.annotations)
        self.assertTrue(
            selected_location([{"location_lat": "invalid"}], []).layout.annotations
        )
        self.assertEqual(list(selected_location([self.valid], []).data[0].lat), [30.2])

    def test_deleted_record_cannot_be_modified(self):
        rid = self.writer.create(self.valid)
        self.writer.delete(rid)
        self.assertEqual(self.writer.update(rid, {"name": "Changed"}), 0)

    def test_migration_checks_invalid_legacy_records(self):
        from scripts.setup_database import configure_database

        other = self.admin[self.db.name + "_migration"]
        try:
            other.animals.insert_one({"animal_id": "legacy"})
            with self.assertRaises(ValueError):
                configure_database(other)
            self.assertEqual(other.animals.count_documents({}), 1)
            other.animals.delete_many({})
            other.animals.insert_one(self.valid)
            configure_database(other)
            configure_database(other)
            self.assertIn("rescue_candidates", other.animals.index_information())
            with self.assertRaises(WriteError):
                other.animals.insert_one({"animal_id": "bad"})
        finally:
            self.admin.drop_database(other.name)

    def test_rescue_results_match_original_notebook(self):
        import ast, json
        from pathlib import Path
        from rescue_queries import RULES, build_query

        notebook = json.loads(
            (
                Path(__file__).resolve().parents[2]
                / "original"
                / "ProjectTwoDashboard.ipynb"
            ).read_text()
        )
        tree = ast.parse("".join(notebook["cells"][0]["source"]))
        node = next(
            n
            for n in tree.body
            if isinstance(n, ast.FunctionDef) and n.name == "build_query"
        )
        namespace = {}
        exec(
            compile(
                ast.Module(body=[node], type_ignores=[]),
                "<original query builder>",
                "exec",
            ),
            namespace,
        )
        for breed in {b for breeds, _, _ in RULES.values() for b in breeds}:
            for age in [19, 20, 25, 26, 156, 157, 300, 301]:
                self.writer.create(
                    {**self.valid, "breed": breed, "age_upon_outcome_in_weeks": age}
                )
        for category in ["water", "mountain", "disaster", "reset"]:
            baseline = {
                r["_id"]
                for r in self.db.animals.find(namespace["build_query"](category))
            }
            enhanced = {r["_id"] for r in self.db.animals.find(build_query(category))}
            self.assertEqual(baseline, enhanced)

"""Enhanced AnimalShelter DAO: bounded access, trusted MongoDB permissions, safe errors."""

import logging
import os
from datetime import datetime, timezone
from bson import ObjectId
from pymongo import MongoClient
from pymongo.errors import PyMongoError
from rescue_queries import build_query, summary_pipeline, candidate_pipeline
from validation import validate_document

LOG = logging.getLogger(__name__)
PUBLIC_FIELDS = [
    "animal_id",
    "animal_type",
    "breed",
    "name",
    "sex_upon_outcome",
    "age_upon_outcome_in_weeks",
    "location_lat",
    "location_long",
    "outcome_type",
]
SORT_FIELDS = {"animal_id", "breed", "age_upon_outcome_in_weeks", "name"}


class DataAccessError(RuntimeError):
    """Safe public database failure; original details never reach the interface."""


class AuthorizationError(DataAccessError):
    pass


class AnimalShelter:
    """Use dedicated database-authenticated credentials; do not accept client-supplied roles."""

    def __init__(self, uri=None, db_name=None, collection_name="animals"):
        uri = uri or os.environ.get("MONGODB_URI")
        if not uri:
            raise ValueError("Set MONGODB_URI to an authenticated database connection.")
        self.client = MongoClient(
            uri, serverSelectionTimeoutMS=5000, connectTimeoutMS=5000
        )
        self.database = self.client[
            db_name or os.environ.get("MONGODB_DATABASE", "aac")
        ]
        self.collection = self.database[collection_name]
        try:
            self.client.admin.command("ping")
            auth = self.client.admin.command("connectionStatus", showPrivileges=True)[
                "authInfo"
            ]
            users = auth.get("authenticatedUsers", [])
            if not users:
                raise AuthorizationError(
                    "An authenticated database account is required."
                )
            self._actor = users[0]["user"]
            self._actions = frozenset(
                action
                for privilege in auth.get("authenticatedUserPrivileges", [])
                if self._matches_resource(privilege["resource"])
                for action in privilege["actions"]
            )
            self._require("find")
        except PyMongoError as error:
            self.client.close()
            self._raise_safe(error, "connect")
        except (AuthorizationError, KeyError):
            self.client.close()
            raise AuthorizationError(
                "Database account does not have the required access."
            ) from None

    def _matches_resource(self, resource):
        return resource.get("db") == self.database.name and resource.get(
            "collection", ""
        ) in ("", self.collection.name)

    def _require(self, action):
        if action not in self._actions:
            raise AuthorizationError(
                "This database account cannot perform the requested operation."
            )

    @staticmethod
    def _raise_safe(error, operation):
        # Log only operation and class; raw driver errors may contain hostnames, data or credentials.
        LOG.warning(
            "Database operation failed: %s (%s)", operation, type(error).__name__
        )
        raise DataAccessError(
            "Database operation failed. Check configuration or contact the administrator."
        ) from None

    @staticmethod
    def _identity(value):
        if not isinstance(value, str) or not ObjectId.is_valid(value):
            raise ValueError("Provide a valid record ID.")
        return {"_id": ObjectId(value)}

    def page(
        self,
        rescue_type="reset",
        page=0,
        page_size=10,
        sort_by="animal_id",
        direction=1,
    ):
        query = build_query(rescue_type)
        if type(page) is not int or not 0 <= page <= 100000:
            raise ValueError("Page must be an integer between 0 and 100000.")
        if type(page_size) is not int or not 1 <= page_size <= 100:
            raise ValueError("Page size must be between 1 and 100.")
        if (
            not isinstance(sort_by, str)
            or sort_by not in SORT_FIELDS
            or type(direction) is not int
            or direction not in (-1, 1)
        ):
            raise ValueError("Select a supported sort field and direction.")
        projection = {key: 1 for key in PUBLIC_FIELDS}
        try:
            # Always tie-break by MongoDB ID; animal IDs can repeat across historical outcomes.
            cursor = (
                self.collection.find(query, projection)
                .sort([(sort_by, direction), ("_id", direction)])
                .skip(page * page_size)
                .limit(page_size)
                .max_time_ms(5000)
            )
            records = list(cursor)
            for record in records:
                record["id"] = str(record.pop("_id"))
            total = self.collection.count_documents(query, maxTimeMS=5000)
            return {
                "records": records,
                "total": total,
                "page": page,
                "page_size": page_size,
                "page_count": (total + page_size - 1) // page_size,
            }
        except PyMongoError as error:
            self._raise_safe(error, "page")

    def summary(self, rescue_type="reset"):
        try:
            return [
                {"breed": row["_id"] or "Unknown", "count": row["count"]}
                for row in self.collection.aggregate(
                    summary_pipeline(rescue_type), maxTimeMS=5000
                )
            ]
        except PyMongoError as error:
            self._raise_safe(error, "summary")

    def candidate_summary(self):
        try:
            return next(
                self.collection.aggregate(candidate_pipeline(), maxTimeMS=5000), {}
            )
        except PyMongoError as error:
            self._raise_safe(error, "candidate_summary")

    def create(self, data):
        self._require("insert")
        clean = validate_document(data)
        now = datetime.now(timezone.utc)
        clean["_audit"] = {
            "created_at": now,
            "created_by": self._actor,
            "updated_at": now,
            "updated_by": self._actor,
        }
        try:
            return str(self.collection.insert_one(clean).inserted_id)
        except PyMongoError as error:
            self._raise_safe(error, "create")

    def update(self, record_id, new_values):
        self._require("update")
        identity = self._identity(record_id)
        clean = validate_document(new_values, partial=True)
        # Dot notation preserves creation metadata while updating modification metadata atomically.
        clean["_audit.updated_at"] = datetime.now(timezone.utc)
        clean["_audit.updated_by"] = self._actor
        try:
            return self.collection.update_one(
                {**identity, "_deleted": {"$ne": True}}, {"$set": clean}
            ).modified_count
        except PyMongoError as error:
            self._raise_safe(error, "update")

    def delete(self, record_id):
        self._require("remove")
        self._require("update")
        identity = self._identity(record_id)
        try:
            # A soft delete keeps provenance and avoids destructive bulk writes.
            return self.collection.update_one(
                {**identity, "_deleted": {"$ne": True}},
                {
                    "$set": {
                        "_deleted": True,
                        "_audit.deleted_at": datetime.now(timezone.utc),
                        "_audit.deleted_by": self._actor,
                    }
                },
            ).modified_count
        except PyMongoError as error:
            self._raise_safe(error, "delete")

    def close(self):
        self.client.close()

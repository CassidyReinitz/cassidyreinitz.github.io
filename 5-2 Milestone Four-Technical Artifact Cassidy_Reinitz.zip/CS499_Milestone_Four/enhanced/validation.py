"""Allowlisted writes and shared MongoDB schema for the existing AAC fields."""

from math import isfinite

ANIMAL_TYPES = ["Bird", "Cat", "Dog", "Livestock", "Other"]
SEX_VALUES = [
    "Intact Female",
    "Intact Male",
    "Neutered Male",
    "Spayed Female",
    "Unknown",
]
TEXT_FIELDS = {
    "animal_id",
    "animal_type",
    "breed",
    "sex_upon_outcome",
    "name",
    "color",
    "outcome_type",
    "outcome_subtype",
    "age_upon_outcome",
    "datetime",
    "monthyear",
    "date_of_birth",
}
NUMERIC_FIELDS = {
    "age_upon_outcome_in_weeks",
    "location_lat",
    "location_long",
    "rec_num",
}
WRITE_FIELDS = TEXT_FIELDS | NUMERIC_FIELDS
REQUIRED = {
    "animal_id",
    "animal_type",
    "breed",
    "sex_upon_outcome",
    "age_upon_outcome_in_weeks",
}


def validate_document(data, partial=False):
    if not isinstance(data, dict) or not data or set(data) - WRITE_FIELDS:
        raise ValueError("Provide nonempty animal data using supported fields only.")
    if not partial and not REQUIRED.issubset(data):
        raise ValueError("Animal ID, type, breed, sex, and age in weeks are required.")
    clean = {}
    for key, value in data.items():
        if key in TEXT_FIELDS:
            if not isinstance(value, str) or len(value.strip()) > 200:
                raise ValueError(
                    "Text values must be strings of at most 200 characters."
                )
            value = value.strip()
            if key in REQUIRED and not value:
                raise ValueError("Required text cannot be empty.")
            if key == "animal_id" and len(value) > 64:
                raise ValueError("Animal ID must contain at most 64 characters.")
            if key == "animal_type" and value not in ANIMAL_TYPES:
                raise ValueError("Unsupported animal type.")
            if key == "sex_upon_outcome" and value not in SEX_VALUES:
                raise ValueError("Unsupported sex value.")
        else:
            if (
                isinstance(value, bool)
                or not isinstance(value, (int, float))
                or not isfinite(value)
            ):
                raise ValueError("Numeric values must be finite numbers.")
            low, high = {"location_lat": (-90, 90), "location_long": (-180, 180)}.get(
                key, (0, float("inf"))
            )
            if not low <= value <= high:
                raise ValueError("Numeric value is outside the permitted range.")
        clean[key] = value
    return clean


PROPERTIES = {key: {"bsonType": "string", "maxLength": 200} for key in TEXT_FIELDS}
for key in REQUIRED & TEXT_FIELDS:
    PROPERTIES[key]["minLength"] = 1
PROPERTIES["animal_id"]["maxLength"] = 64
PROPERTIES["animal_type"]["enum"] = ANIMAL_TYPES
PROPERTIES["sex_upon_outcome"]["enum"] = SEX_VALUES
for key in NUMERIC_FIELDS:
    PROPERTIES[key] = {"bsonType": ["int", "long", "double", "decimal"], "minimum": 0}
PROPERTIES["location_lat"].update(minimum=-90, maximum=90)
PROPERTIES["location_long"].update(minimum=-180, maximum=180)
PROPERTIES["_deleted"] = {"bsonType": "bool"}
PROPERTIES["_audit"] = {"bsonType": "object"}
# Allow legacy AAC metadata. The application write boundary remains an explicit allowlist.
VALIDATOR = {
    "$jsonSchema": {
        "bsonType": "object",
        "required": sorted(REQUIRED),
        "properties": PROPERTIES,
    }
}
INDEXES = [
    (
        "rescue_candidates",
        [
            ("animal_type", 1),
            ("breed", 1),
            ("age_upon_outcome_in_weeks", 1),
            ("_id", 1),
        ],
    ),
    ("animal_page", [("animal_id", 1), ("_id", 1)]),
    ("breed_page", [("breed", 1), ("_id", 1)]),
]

"""Preserve the original CS 340 breed and age rules as validated query templates."""

from copy import deepcopy

RULES = {
    "water": (["Labrador Retriever Mix", "Chesapeake Bay Retriever"], 26, 156),
    "mountain": (
        [
            "German Shepherd",
            "Alaskan Malamute",
            "Old English Sheepdog",
            "Siberian Husky",
            "Rottweiler",
        ],
        26,
        156,
    ),
    "disaster": (
        [
            "Doberman Pinscher",
            "German Shepherd",
            "Golden Retriever",
            "Bloodhound",
            "Rottweiler",
        ],
        20,
        300,
    ),
}
LABELS = {
    "reset": "All animals",
    "water": "Water rescue",
    "mountain": "Mountain or wilderness rescue",
    "disaster": "Disaster or individual tracking",
}


def build_query(rescue_type="reset"):
    if rescue_type == "reset":
        return {"_deleted": {"$ne": True}}
    if not isinstance(rescue_type, str) or rescue_type not in RULES:
        raise ValueError("Select a supported rescue category.")
    breeds, minimum, maximum = RULES[rescue_type]
    return {
        "_deleted": {"$ne": True},
        "animal_type": "Dog",
        "breed": {"$in": deepcopy(breeds)},
        "age_upon_outcome_in_weeks": {"$gte": minimum, "$lte": maximum},
    }


def summary_pipeline(rescue_type="reset"):
    """Database-side breed counts over all matches, independent of displayed page."""
    return [
        {"$match": build_query(rescue_type)},
        {"$group": {"_id": "$breed", "count": {"$sum": 1}}},
        {"$sort": {"count": -1, "_id": 1}},
    ]


def candidate_pipeline():
    """Separate branches preserve overlapping rescue categories rather than reclassify them."""
    return [{"$facet": {key: summary_pipeline(key) for key in RULES}}]

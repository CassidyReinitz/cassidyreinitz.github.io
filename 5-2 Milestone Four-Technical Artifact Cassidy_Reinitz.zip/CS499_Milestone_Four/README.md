# CS 499 Milestone Four submission

Cassidy Reinitz — Enhancement Three — Databases

- `original/`: all four original CS 340 files, preserved byte-for-byte from the supplied archive.
- `enhanced/`: database service, dashboard, schema/index migration, authentication-aware permissions,
  test runner, benchmark, requirements, and operating instructions.
- `evidence/`: actual integration test output and measured query-plan comparison.

Read `enhanced/README.md` for installation, database migration, application use, and reproducible tests.
Submit this ZIP with the separate Word enhancement narrative.

The original notebook includes the historical course credential literal and relies on a logo not
included in the source archive. That file is retained for original/enhanced assessment; the enhanced
application has no embedded credentials and no missing logo dependency. Use newly provisioned accounts
when running the enhancement. The archive contains no original shelter dataset; tests use clearly
identified synthetic fixtures. No MongoDB executable, database files, dependency folders, or active
verification credentials are included.
